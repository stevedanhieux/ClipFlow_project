# ClipFlow — updated video editor

## Start

Install Node.js 22.13 or newer. In this folder run:

```
npm install
npm run build
npm start
```

Open http://127.0.0.1:3000. On Windows, Start-ClipFlow.cmd starts an already installed project. Copy .env.example to .env to configure providers and tools. The server stays local by default; do not expose it publicly without authentication and production hardening.

For MP4 export, install FFmpeg and FFprobe with H.264, AAC, and drawtext support: https://ffmpeg.org/download.html. Add them to PATH or configure FFMPEG_PATH and FFPROBE_PATH in .env. Social import additionally needs yt-dlp: https://github.com/yt-dlp/yt-dlp. Set YT_DLP_PATH if it is not on PATH.

## Use the editor

Choose Video editor / AI director. Drop videos or images, or choose Social import. Imported media streams to disk. The first footage import replaces starter color slides; existing imported clips remain.

Use checkboxes to select clips. Drag rows to reorder. Set duration, source start time, captions, and source volume. Play a clip and choose Split at playhead. Undo/redo covers structural and numeric edits in the current session; title/caption text auto-saves without creating undo history entries.

The source player previews individual clips. Export MP4 creates an assembled video with hard cuts, fitted framing, simple captions, and source audio. Slide studio retains its separate canvas transitions, caption presets, and procedural music. This is a basic single video/audio timeline; stacked tracks, compositing, keyframes, professional color grading, and Premiere/Final Cut parity are not implemented.

Social import supports public HTTPS links from YouTube, Vimeo, TikTok, Instagram, and Facebook through yt-dlp. Private, login-only, age-restricted, or platform-blocked videos may fail. Import content you have permission to use. Browser preview depends on codec support; H.264 MP4 is the safest choice.

There is no app-level 60-minute cap. MP4 renders write to disk; the export library keeps file references instead of loading the complete MP4 into browser memory. Leave room for sources, intermediate files, and final renders. Maximum 500 clips per render. Keep the server running; jobs cannot resume after restarting it. A complete video over an hour was not rendered during validation.

After rendering, Download MP4 and Post to YouTube/Vimeo open the platform upload flow. Select your downloaded MP4 there. Automatic posting/OAuth is not implemented. YouTube account verification is required above 15 minutes; its current limit is 12 hours or 256 GB, whichever is smaller: https://support.google.com/youtube/answer/71673.

## AI drafts and revisions

Choose a provider, describe your edit, and select Create AI draft. Review its clips or Render draft preview to see the assembled MP4 before accepting. Accept, discard, or type another command and choose Revise draft.

- Ollama: local inference without API fees. Install https://ollama.com and run `ollama pull llama3.2`; keep Ollama running. Hardware, memory, download, and electricity requirements still apply.
- Gemini: server API key required. Eligible models/accounts have limited free quotas, not guaranteed unlimited free access: https://ai.google.dev/gemini-api/docs/pricing.
- OpenAI / ChatGPT: the OpenAI API may be billed separately from ChatGPT subscriptions: https://openai.com/api/pricing/.
- Claude: API key and credits required: https://support.anthropic.com/en/articles/8977456-how-do-i-pay-for-my-api-usage.
- Compatible provider: configure an OpenAI-compatible endpoint, key, and model. Its own quotas/pricing apply.

Model names can be overridden in the UI or .env because availability changes. API keys stay on the server.

The director receives your instructions and timeline metadata, including filenames/captions, rather than video footage. It proposes cuts, sequencing, framing, captions, and durations. It does not inspect video frames, identify highlights from footage, transcribe speech, generate new footage, or generate spoken narration. Existing Gemini slide generation accepts scripts, images, and PDFs via Import & Direct.

Remember accepted instructions is opt-in. Accepted commands are saved locally and reused as context. Clear preference memory removes them. This is preference memory, not model training or autonomous self-learning. Provider failures display errors rather than silently substituting generic placeholders.

## Delete exports

Export Video and Video editor both show Saved exports. Choose individual checkboxes, Select all, Delete selected, an individual Delete button, or Delete all. Deletion asks for confirmation.

Canvas exports are stored in browser IndexedDB. MP4 library entries reference server files; deleting them also deletes those exported MP4s. Projects, original footage, and downloaded copies remain. The server checks a render manifest before allowing deletion, protecting imported source files.

The export index belongs to this browser profile. Clearing browser storage removes it. Moving computers does not migrate saved browser data automatically. Preserve data/ to keep server footage and MP4s. Intermediate render folders and unused sources require manual disk housekeeping.

## Validation

TypeScript checks, production build, and integration tests passed. Tests cover uploads, social URL restrictions, AI drafts through a mock Ollama server, invalid clip boundaries, invalid render requests, missing jobs, and protection against deleting source footage.

With FFMPEG_PATH and FFPROBE_PATH configured, `npm test` also synthesizes footage and checks real trimming, captions, 1080p MP4 encoding, audio, output duration, export deletion, and preservation of the source. This real render test passed on Windows. Browser checks covered import, editing, and export controls.

Live cloud providers and social downloads were not tested: no user credentials were supplied and yt-dlp was not installed. These checks do not guarantee every possible app error has been eliminated.

Other fixes include real-time canvas recording (the old accelerated loop shortened exports), active-scene selection, empty timeline validation, track/URL cleanup, MP4 sharing extensions, missing-key startup, visible caption-generation errors, actual PDF input to Gemini instead of reading PDF binary as text, and a Windows-compatible startup workflow.
