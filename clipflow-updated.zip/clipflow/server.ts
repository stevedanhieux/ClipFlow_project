import { installStudio } from './studioServer';
import express, { type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Shared server-side Gemini client per gemini-api skill guide
const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

// Fallback scene generator if Gemini is unavailable or rate-limited
function generateSmartFallbackStoryboard(prompt: string, platform: string, sourceType: string) {
  const cleanPrompt = prompt.trim() || 'Exciting creator update';
  const sentences = cleanPrompt
    .split(/[.\n;]+/)
    .map(s => s.trim())
    .filter(s => s.length > 5);

  const fallbackScenes = [
    {
      sceneNumber: 1,
      caption: sentences[0]?.slice(0, 48) || 'Wait until you see this secret...',
      voiceover: sentences[0] || 'Stop scrolling because this changes everything you know about creation.',
      duration: 3.0,
      transition: 'zoom_in',
      visualDirection: 'Hook shot with fast push-in and vibrant lighting',
      focalPoint: { x: 0.5, y: 0.45 },
      zoomScale: 1.15,
      accentColor: '#f43f5e',
    },
    {
      sceneNumber: 2,
      caption: sentences[1]?.slice(0, 48) || 'Here is the step most people miss',
      voiceover: sentences[1] || 'Step 1 is focusing on what your audience actually needs right now.',
      duration: 3.2,
      transition: 'whip_pan',
      visualDirection: 'Dynamic pan across the core subject with high focus',
      focalPoint: { x: 0.48, y: 0.5 },
      zoomScale: 1.08,
      accentColor: '#3b82f6',
    },
    {
      sceneNumber: 3,
      caption: sentences[2]?.slice(0, 48) || 'The game-changing breakthrough',
      voiceover: sentences[2] || 'Notice how immediate results compound when you automate the editing.',
      duration: 3.0,
      transition: 'glitch',
      visualDirection: 'Punchy transition with micro-zoom emphasizing key metric',
      focalPoint: { x: 0.52, y: 0.48 },
      zoomScale: 1.2,
      accentColor: '#8b5cf6',
    },
    {
      sceneNumber: 4,
      caption: sentences[3]?.slice(0, 48) || 'Try this in your next video!',
      voiceover: sentences[3] || 'Save this for your next video and follow for daily creator tips!',
      duration: 2.8,
      transition: 'fade',
      visualDirection: 'Outro framing with clear CTA and memorable sign-off',
      focalPoint: { x: 0.5, y: 0.5 },
      zoomScale: 1.05,
      accentColor: '#10b981',
    },
  ];

  return {
    title: cleanPrompt.slice(0, 40) || 'Viral Short-Form Clip',
    hook: sentences[0] || 'Wait until you see this...',
    scenes: fallbackScenes,
    suggestedMusic: 'Viral Phonk & Bass',
    targetAudience: 'Content creators, entrepreneurs & social media enthusiasts',
    viralScore: 0,
    captions: {
      tiktok: {
        text: `Did you know this? 🤯 Try this workflow today! Drop a comment if you want the full template 👇`,
        hashtags: ['#creatorhack', '#contentcreator', '#fyp', '#viralvideo', '#editingtips', '#tiktokgrowth'],
      },
      shorts: {
        text: `The #1 secret to 10x faster short-form content. Watch until the end! Subscribe for daily tips.`,
        hashtags: ['#Shorts', '#CreatorLife', '#Productivity', '#ViralTips', '#YouTubeShorts'],
      },
      reels: {
        text: `Save this before you plan your next batch of content! ✨ Let me know your thoughts in the comments.`,
        hashtags: ['#reelsvideo', '#reelsinstagram', '#contentcreation', '#videomarketing', '#creators'],
      },
    },
  };
}

// Endpoint: Generate Full Video Storyboard & Smart Scenes from Prompt/File/Image
app.post('/api/gemini/generate-storyboard', async (req: Request, res: Response) => {
  try {
    const {
      promptText,
      sourceType,
      fileName,
      targetPlatform = 'tiktok',
      aspectRatio = '9:16',
      pacing = 'fast',
      imageMimeType,
      imageBase64,
    } = req.body;

    const rawContent = (promptText || '').trim();
    if (!rawContent && !imageBase64) {
      return res.status(400).json({ error: 'Please provide either text/script content or an uploaded image.' });
    }

    const platformGuidance = {
      tiktok: 'Ultra-fast pacing (under 3.5s per scene), intense opening hook, high-energy vocabulary, text overlays optimized for mobile safe zones.',
      shorts: 'High retention focus, curiosity gap in first 2 seconds, punchy visual cuts, clear loop potential.',
      reels: 'Aesthetic, cinematic framing, conversational yet authoritative tone, clean visual flow.',
      cross_platform: 'Universal high-engagement structure adaptable across TikTok, Shorts, and Reels.',
    }[targetPlatform as 'tiktok' | 'shorts' | 'reels' | 'cross_platform'] || 'Snappy and engaging short-form video.';

    const systemPrompt = `You are an elite short-form video director and viral content strategist for TikTok, YouTube Shorts, and Instagram Reels.
Your task is to take the provided input (script, document text, CSV data, PDF notes, or image) and transform it into a production-ready, highly engaging short-form video storyboard.

Platform Strategy: ${platformGuidance}
Target Aspect Ratio: ${aspectRatio}
Desired Pacing: ${pacing}
Source Type: ${sourceType || 'text'} ${fileName ? `(File: ${fileName})` : ''}

Break down the story into 3 to 6 compelling scenes:
- Each scene must have a very punchy on-screen caption (under 10 words, easy to read on mobile).
- Each scene must have natural spoken voiceover narration (10-25 words).
- Scene duration between 2.2 and 4.2 seconds.
- Suggest transition types: "zoom_in", "zoom_out", "glitch", "whip_pan", "flash", "slide_left", "fade".
- Specify focalPoint { x: 0.0 - 1.0, y: 0.0 - 1.0 } for smart vertical cropping.
- Provide a zoomScale (between 1.05 and 1.25) for Ken Burns dynamic motion.
- Provide custom viral captions & trending hashtags for TikTok, Shorts, and Reels.`;

    let contentsPayload: any = [
      {
        role: 'user',
        parts: [] as any[],
      },
    ];

    if (imageBase64 && imageMimeType) {
      contentsPayload[0].parts.push({
        inlineData: {
          mimeType: imageMimeType,
          data: imageBase64,
        },
      });
      contentsPayload[0].parts.push({
        text: `Analyze this image and the user's brief: "${rawContent || 'Turn this photo into an engaging viral short-form video clip'}". Generate the video storyboard.`,
      });
    } else {
      contentsPayload[0].parts.push({
        text: `Here is the input content/script to convert into a short-form video:\n\n${rawContent}`,
      });
    }

    const response = await getAI().models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: contentsPayload,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            hook: { type: Type.STRING },
            suggestedMusic: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            viralScore: { type: Type.INTEGER },
            scenes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  sceneNumber: { type: Type.INTEGER },
                  caption: { type: Type.STRING },
                  voiceover: { type: Type.STRING },
                  duration: { type: Type.NUMBER },
                  transition: { type: Type.STRING },
                  visualDirection: { type: Type.STRING },
                  focalPoint: {
                    type: Type.OBJECT,
                    properties: {
                      x: { type: Type.NUMBER },
                      y: { type: Type.NUMBER },
                    },
                    required: ['x', 'y'],
                  },
                  zoomScale: { type: Type.NUMBER },
                  accentColor: { type: Type.STRING },
                },
                required: ['sceneNumber', 'caption', 'voiceover', 'duration', 'transition', 'visualDirection'],
              },
            },
            captions: {
              type: Type.OBJECT,
              properties: {
                tiktok: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['text', 'hashtags'],
                },
                shorts: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['text', 'hashtags'],
                },
                reels: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['text', 'hashtags'],
                },
              },
              required: ['tiktok', 'shorts', 'reels'],
            },
          },
          required: ['title', 'hook', 'scenes', 'suggestedMusic', 'captions'],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response received from Gemini');
    }

    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (err: any) {
    console.error('Error in /api/gemini/generate-storyboard:', err);
    // Provide robust intelligent fallback if API fails or quota exceeded
    const fallback = generateSmartFallbackStoryboard(
      req.body.promptText || 'Viral Creator Clip',
      req.body.targetPlatform || 'tiktok',
      req.body.sourceType || 'text'
    );
    return res.status(503).json({ error: 'Gemini generation failed. Configure your API key and model, or use the local AI director.' });
  }
});

// Endpoint: Generate Viral Captions & Trending Hashtags for all platforms
app.post('/api/gemini/viral-captions', async (req: Request, res: Response) => {
  try {
    const { title, scriptSummary, niche = 'general', targetPlatform = 'all' } = req.body;

    const response = await getAI().models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: `Generate viral caption packages for short-form video:
Title: ${title}
Summary/Script: ${scriptSummary}
Niche: ${niche}
Target Platform: ${targetPlatform}`,
      config: {
        systemInstruction: `You are a viral social media growth hacker. Generate top-tier copy with:
1. High-CTR hooks (first 80 chars before "more")
2. Engaging body copy with curiosity and CTA
3. 6 to 10 trending hashtags categorized by niche and broad discovery.
Format response strictly in JSON.`,
        temperature: 0.75,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tiktok: {
              type: Type.OBJECT,
              properties: {
                hook: { type: Type.STRING },
                caption: { type: Type.STRING },
                hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                callToAction: { type: Type.STRING },
              },
              required: ['hook', 'caption', 'hashtags', 'callToAction'],
            },
            shorts: {
              type: Type.OBJECT,
              properties: {
                hook: { type: Type.STRING },
                caption: { type: Type.STRING },
                hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                callToAction: { type: Type.STRING },
              },
              required: ['hook', 'caption', 'hashtags', 'callToAction'],
            },
            reels: {
              type: Type.OBJECT,
              properties: {
                hook: { type: Type.STRING },
                caption: { type: Type.STRING },
                hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                callToAction: { type: Type.STRING },
              },
              required: ['hook', 'caption', 'hashtags', 'callToAction'],
            },
          },
          required: ['tiktok', 'shorts', 'reels'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (err: any) {
    console.error('Error generating viral captions:', err);
    return res.status(503).json({ error: 'Caption generation failed. Check Gemini configuration and quota.' });
  }
});

// Production or Vite development middleware setup
function getAI() { if (!ai) throw new Error('Configure GEMINI_API_KEY to use Gemini.'); return ai; }

async function startServer() {
  await installStudio(app);
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, process.env.HOST || '127.0.0.1', () => {
    console.log(`[ClipFlow] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[ClipFlow] Failed to start server:', err);
});
