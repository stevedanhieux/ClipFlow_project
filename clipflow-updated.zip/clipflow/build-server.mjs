import { stripTypeScriptTypes } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
for (const name of ['server', 'studioServer']) {
  const source = readFileSync(`${name}.ts`, 'utf8').replace("from './studioServer'", "from './studioServer.js'");
  writeFileSync(`${name}.js`, stripTypeScriptTypes(source));
}
