import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { installStudio, run } from '../studioServer.js';
import { readFile, unlink } from 'node:fs/promises';
import path from 'node:path';

test('imports, provider edits, invalid edits, and export validation', async () => {
  const mock = express(); mock.use(express.json()); let invalid = false;
  mock.post('/api/chat', (_req,res) => res.json({message:{content:JSON.stringify({title:'Edited',aspectRatio:'16:9',scenes:[{sourceId:'source',caption:'Hello',duration:invalid?5000:2,trimStart:1,transition:'fade'}]})}}));
  const aiServer = mock.listen(0,'127.0.0.1'); await new Promise(resolve => aiServer.once('listening',resolve));
  process.env.OLLAMA_URL = `http://127.0.0.1:${aiServer.address().port}`;
  const app = express(); app.use(express.json()); await installStudio(app);
  const server = app.listen(0,'127.0.0.1'); await new Promise(resolve => server.once('listening',resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (route,body) => fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  try {
    const upload = await fetch(base+'/api/studio/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-File-Name':'test%20image.png'},body:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aWQAAAABJRU5ErkJggg==','base64')});
    assert.equal(upload.status,200); const media = await upload.json(); assert.match(media.url,/^\/media\/.+\.png$/);
    assert.equal((await fetch(base+media.url)).status,200);
    const blocked = await post('/api/studio/social',{url:'https://127.0.0.1/private'}); assert.equal(blocked.status,400);
    const badUpload = await fetch(base+'/api/studio/upload',{method:'POST',headers:{'X-File-Name':'x.exe'},body:'x'}); assert.equal(badUpload.status,400);
    const project = {id:'p',scenes:[{id:'source',mediaType:'video',mediaUrl:media.url,duration:10,sourceDuration:10,caption:'Original'}]};
    const edit = await post('/api/studio/direct',{provider:'ollama',command:'Trim',project}); assert.equal(edit.status,200);
    const draft = await edit.json(); assert.equal(draft.title,'Edited'); assert.equal(draft.scenes[0].duration,2); assert.equal(draft.scenes[0].mediaUrl,media.url); assert.notEqual(draft.scenes[0].id,'source');
    invalid=true; assert.equal((await post('/api/studio/direct',{provider:'ollama',command:'Trim',project})).status,400);
    assert.equal((await post('/api/studio/render',{project:{scenes:[]}})).status,400);
    assert.equal((await post('/api/studio/render',{project:{scenes:[{mediaUrl:'/media/../../file',duration:2}]}})).status,400);
    assert.equal((await post('/api/studio/render',{project:{scenes:[{mediaUrl:media.url,duration:-1}]}})).status,400);
    assert.equal((await fetch(base+'/api/studio/render/nonexistent')).status,404);
    assert.equal((await fetch(base+'/api/studio/export',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:media.url})})).status,400);
    if (process.env.FFMPEG_PATH && process.env.FFPROBE_PATH) {
      const source = path.resolve('data/test-source.mp4');
      await run('ffmpeg',['-y','-f','lavfi','-i','color=c=blue:s=320x180:d=3','-f','lavfi','-i','sine=frequency=440:duration=3','-c:v','libx264','-c:a','aac','-shortest',source]);
      const upload = await fetch(base+'/api/studio/upload',{method:'POST',headers:{'X-File-Name':'source.mp4','Content-Type':'application/octet-stream'},body:await readFile(source)});
      const video = await upload.json(); assert.equal(upload.status,200);
      const render = await post('/api/studio/render',{project:{aspectRatio:'16:9',scenes:[{mediaType:'video',mediaUrl:video.url,duration:1.5,trimStart:1,sourceVolume:.5,caption:'Render test'}]}});
      assert.equal(render.status,200); const {id} = await render.json(); let result;
      for (let attempt=0;attempt<60;attempt++) { await new Promise(resolve=>setTimeout(resolve,500));result=await (await fetch(base+`/api/studio/render/${id}`)).json();if(result.status!=='rendering')break; }
      assert.equal(result.status,'complete',result.error);
      const file=path.resolve('data/media',path.basename(result.url));
      const probe=JSON.parse(await run('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file]));
      assert.ok(Math.abs(Number(probe.format.duration)-1.5)<.15);
      assert.ok(probe.streams.some(s=>s.codec_type==='audio'));
      assert.equal(probe.streams.find(s=>s.codec_type==='video').width,1920);
      assert.equal((await fetch(base+'/api/studio/export',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:result.url})})).status,200);
      assert.equal((await fetch(base+result.url)).status,404);
      assert.equal((await fetch(base+video.url)).status,200);
      await unlink(source);
      console.log('Verified real FFmpeg trim, 1080p MP4 encoding, captions, audio track, output duration, export deletion, and source preservation.');
    }
    console.log('Verified upload, URL restrictions, AI draft preservation, boundary validation, render rejection, and source-file deletion protection.');
  } finally { server.close(); aiServer.close(); }
});
