@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Run npm install and npm run build in this folder first.
  pause
  exit /b 1
)
set NODE_ENV=production
 echo Open http://127.0.0.1:3000 in your browser. Keep this window open.
node build-server.mjs
if errorlevel 1 exit /b 1
node server.js
pause
