import { DirectorWorkspace } from './components/DirectorWorkspace';
import React, { useState, useEffect, useCallback } from 'react';
import {
  Film,
  Sparkles,
  Download,
  Upload,
  Plus,
  Sliders,
  FolderOpen,
  Zap,
  Play,
  Share2,
} from 'lucide-react';
import { Project, Scene, TargetPlatform, AspectRatio } from './types';
import { Header } from './components/Header';
import { InputSection } from './components/InputSection';
import { VideoPreviewCanvas } from './components/VideoPreviewCanvas';
import { SceneTimeline } from './components/SceneTimeline';
import { SceneInspector } from './components/SceneInspector';
import { AIStudioPanel } from './components/AIStudioPanel';
import { ExportModal } from './components/ExportModal';
import { ProjectLibraryModal } from './components/ProjectLibraryModal';
import { generateStoryboard, createDefaultScenes } from './services/geminiService';
import {
  getAllSavedProjects,
  saveProjectToStorage,
  deleteProjectFromStorage,
} from './services/projectStorage';

export default function App() {
  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('clipflow_theme');
    return (saved as 'dark' | 'light') || 'dark';
  });

  // Apply dark theme class to <html>
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('clipflow_theme', theme);
  }, [theme]);

  // Project state
  const [project, setProject] = useState<Project>(() => {
    const saved = getAllSavedProjects();
    if (saved.length > 0) {
      return saved[0];
    }
    return createInitialProject();
  });

  const [savedProjects, setSavedProjects] = useState<Project[]>(() => getAllSavedProjects());
  const [activeTab, setActiveTab] = useState<'studio' | 'input' | 'ai' | 'projects' | 'editor'>('studio');

  // Preview player playback state
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Modals & Drawers
  const [editingScene, setEditingScene] = useState<Scene | null>(null);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isProjectsOpen, setIsProjectsOpen] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Auto-save project whenever it changes
  useEffect(() => {
    saveProjectToStorage(project);
    setSavedProjects(getAllSavedProjects());
  }, [project]);

  // Handle generation from prompt/file/image
  const handleGenerate = async (params: {
    promptText: string;
    sourceType: 'prompt' | 'file' | 'image';
    fileName?: string;
    targetPlatform: TargetPlatform;
    aspectRatio: AspectRatio;
    pacing: 'fast' | 'moderate' | 'cinematic';
    imageMimeType?: string;
    imageBase64?: string;
  }) => {
    setIsGenerating(true);
    try {
      const result = await generateStoryboard(params);

      const newProject: Project = {
        id: `proj-${Date.now()}`,
        title: result.title || params.fileName || 'Viral Clip',
        targetPlatform: params.targetPlatform,
        aspectRatio: params.aspectRatio,
        captionStyle: 'tiktok_yellow',
        musicVibe: 'phonk',
        musicVolume: 75,
        scenes: result.scenes,
        viralCaptions: {
          tiktok: { ...result.captions.tiktok, hook: result.hook },
          shorts: { ...result.captions.shorts, hook: result.hook },
          reels: { ...result.captions.reels, hook: result.hook },
        },
        viralScore: result.viralScore,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      setProject(newProject);
      saveProjectToStorage(newProject);
      setSavedProjects(getAllSavedProjects());
      setCurrentTime(0);
      setActiveTab('studio');
    } catch (err: any) {
      console.error('Failed to generate project:', err);
      throw err;
    } finally {
      setIsGenerating(false);
    }
  };

  const handleNewProject = () => {
    const initial = createInitialProject();
    setProject(initial);
    saveProjectToStorage(initial);
    setSavedProjects(getAllSavedProjects());
    setCurrentTime(0);
    setActiveTab('input');
  };

  const handleSelectProject = (proj: Project) => {
    setProject(proj);
    setCurrentTime(0);
    setIsProjectsOpen(false);
    setActiveTab('studio');
  };

  const handleDeleteProject = (id: string) => {
    const remaining = deleteProjectFromStorage(id);
    setSavedProjects(remaining);
    if (project.id === id) {
      setProject(remaining[0] || createInitialProject());
    }
  };

  const handleSeekToScene = (sceneIndex: number) => {
    let acc = 0;
    for (let i = 0; i < sceneIndex; i++) {
      acc += project.scenes[i]?.duration || 0;
    }
    setCurrentTime(acc + 0.05);
  };

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex flex-col font-sans transition-colors duration-200">
      {/* 3-Zone Clean Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        setTheme={setTheme}
        onOpenExport={() => { setIsPlaying(false); if (project.scenes.some(s => s.mediaType === 'video')) setActiveTab('editor'); else setIsExportOpen(true); }}
        onNewProject={handleNewProject}
        projectTitle={project.title}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6 pb-24 md:pb-10">
        <div className="flex gap-3 mb-4"><button className="px-4 py-2 rounded-xl bg-rose-600 text-white" onClick={() => {setIsPlaying(false);setActiveTab('editor');}}>Video editor / AI director</button><button className="px-4 py-2 rounded-xl bg-zinc-200 dark:bg-zinc-800" onClick={() => setActiveTab('studio')}>Slide studio</button></div>
        {activeTab === 'editor' && <DirectorWorkspace key={project.id} project={project} onUpdate={setProject} />}
        {/* Tab 1: Studio Editor (Centerpiece) */}
        {activeTab === 'studio' && project.scenes.some(s => s.mediaType === 'video') && <DirectorWorkspace key={project.id} project={project} onUpdate={setProject} />}
        {activeTab === 'studio' && !project.scenes.some(s => s.mediaType === 'video') && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Center / Primary Preview Column (Mobile-first vertical canvas) */}
            <div className="lg:col-span-7 flex flex-col items-center justify-center space-y-4">
              <VideoPreviewCanvas
                project={project}
                currentTime={currentTime}
                setCurrentTime={setCurrentTime}
                isPlaying={isPlaying}
                setIsPlaying={setIsPlaying}
                onEditScene={scene => setEditingScene(scene)}
              />

              {/* Scene Timeline Strip immediately below canvas */}
              <div className="w-full">
                <SceneTimeline
                  project={project}
                  onUpdateProject={setProject}
                  currentTime={currentTime}
                  onSeekToScene={handleSeekToScene}
                  onOpenSceneInspector={scene => setEditingScene(scene)}
                />
              </div>
            </div>

            {/* Right Desktop Inspector & Quick Automation Tools */}
            <div className="lg:col-span-5 space-y-5">
              {/* Quick Project Overview Card */}
              <div className="p-5 rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                      Clip Settings
                    </span>
                    <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100 truncate max-w-[220px]">
                      {project.title}
                    </h2>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setActiveTab('input')}
                      className="px-2.5 py-1 text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer min-h-[36px]"
                    >
                      New Import
                    </button>
                    <button
                      onClick={() => setActiveTab('ai')}
                      className="px-2.5 py-1 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer min-h-[36px]"
                    >
                      AI Suite
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                  <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <span className="text-[10px] text-zinc-400 block">Platform</span>
                    <span className="font-semibold capitalize text-zinc-800 dark:text-zinc-200">
                      {project.targetPlatform.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <span className="text-[10px] text-zinc-400 block">Aspect Ratio</span>
                    <span className="font-semibold text-zinc-800 dark:text-zinc-200">
                      {project.aspectRatio}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <span className="text-[10px] text-zinc-400 block">Audio Beat</span>
                    <span className="font-semibold capitalize text-zinc-800 dark:text-zinc-200">
                      {project.musicVibe}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800">
                    <span className="text-[10px] text-zinc-400 block">Caption Preset</span>
                    <span className="font-semibold capitalize text-zinc-800 dark:text-zinc-200">
                      {project.captionStyle.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Embedded AI Studio Tools in sidebar */}
              <AIStudioPanel project={project} onUpdateProject={setProject} />
            </div>
          </div>
        )}

        {/* Tab 2: Input & File Directing */}
        {activeTab === 'input' && (
          <InputSection
            onGenerate={handleGenerate}
            isGenerating={isGenerating}
            targetPlatform={project.targetPlatform}
            setTargetPlatform={platform => setProject({ ...project, targetPlatform: platform })}
            aspectRatio={project.aspectRatio}
            setAspectRatio={ratio => setProject({ ...project, aspectRatio: ratio })}
          />
        )}

        {/* Tab 3: Dedicated AI Studio Suite */}
        {activeTab === 'ai' && (
          <AIStudioPanel project={project} onUpdateProject={setProject} />
        )}

        {/* Tab 4: Saved Projects List */}
        {activeTab === 'projects' && (
          <div className="max-w-2xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-zinc-100">
                Your Video Library
              </h2>
              <button
                onClick={handleNewProject}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 rounded-lg hover:bg-rose-700 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create New</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {savedProjects.map(p => (
                <div
                  key={p.id}
                  onClick={() => handleSelectProject(p)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    p.id === project.id
                      ? 'border-rose-500 bg-rose-50/40 dark:bg-rose-950/20'
                      : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 hover:border-zinc-300'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{p.title}</div>
                    <div className="text-xs text-zinc-500">
                      {p.scenes.length} Scenes · {p.targetPlatform} ·{' '}
                      {new Date(p.updatedAt || p.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  <button
                    onClick={e => {
                      e.stopPropagation();
                      handleSelectProject(p);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 transition-colors cursor-pointer"
                  >
                    Open Editor
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Mobile Fixed Thumb-Zone Bottom Tab Bar (Under 15% Viewport Cap) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-t border-zinc-200 dark:border-zinc-800 h-16 px-2 flex items-center justify-around">
        <button
          onClick={() => setActiveTab('studio')}
          className={`flex flex-col items-center justify-center w-16 h-12 rounded-xl transition-colors cursor-pointer ${
            activeTab === 'studio'
              ? 'text-rose-600 dark:text-rose-400 font-semibold'
              : 'text-zinc-500 dark:text-zinc-400'
          }`}
        >
          <Film className="w-4 h-4" />
          <span className="text-[10px] mt-1">Studio</span>
        </button>

        <button
          onClick={() => setActiveTab('input')}
          className={`flex flex-col items-center justify-center w-16 h-12 rounded-xl transition-colors cursor-pointer ${
            activeTab === 'input'
              ? 'text-rose-600 dark:text-rose-400 font-semibold'
              : 'text-zinc-500 dark:text-zinc-400'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span className="text-[10px] mt-1">Import</span>
        </button>

        <button
          onClick={() => setActiveTab('ai')}
          className={`flex flex-col items-center justify-center w-16 h-12 rounded-xl transition-colors cursor-pointer ${
            activeTab === 'ai'
              ? 'text-rose-600 dark:text-rose-400 font-semibold'
              : 'text-zinc-500 dark:text-zinc-400'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span className="text-[10px] mt-1">AI Magic</span>
        </button>

        <button
          onClick={() => setIsExportOpen(true)}
          className="flex flex-col items-center justify-center w-16 h-12 rounded-xl text-rose-600 dark:text-rose-400 font-semibold cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span className="text-[10px] mt-1">Export</span>
        </button>
      </nav>

      {/* Modals */}
      <SceneInspector
        scene={editingScene}
        isOpen={Boolean(editingScene)}
        onClose={() => setEditingScene(null)}
        onSaveScene={updatedScene => {
          const newScenes = project.scenes.map(s => (s.id === updatedScene.id ? updatedScene : s));
          setProject({ ...project, scenes: newScenes });
          setEditingScene(null);
        }}
      />

      <ExportModal
        project={project}
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

      <ProjectLibraryModal
        isOpen={isProjectsOpen}
        onClose={() => setIsProjectsOpen(false)}
        savedProjects={savedProjects}
        activeProjectId={project.id}
        onSelectProject={handleSelectProject}
        onDeleteProject={handleDeleteProject}
        onNewProject={() => {
          handleNewProject();
          setIsProjectsOpen(false);
        }}
        onImportProject={imported => {
          setProject(imported);
          saveProjectToStorage(imported);
          setSavedProjects(getAllSavedProjects());
          setIsProjectsOpen(false);
          setActiveTab('studio');
        }}
      />
    </div>
  );
}

function createInitialProject(): Project {
  return {
    id: `proj-${Date.now()}`,
    title: 'Stop Scrolling: The 3 Productivity Rules',
    targetPlatform: 'tiktok',
    aspectRatio: '9:16',
    captionStyle: 'tiktok_yellow',
    musicVibe: 'phonk',
    musicVolume: 75,
    scenes: createDefaultScenes('Stop scrolling: The 3 productivity rules'),
    viralCaptions: {
      tiktok: {
        hook: 'Wait till you see rule #3 🤯',
        text: 'This completely changed my workflow. Save this before planning your next session!',
        hashtags: ['#creatorhack', '#contentcreator', '#fyp', '#productivity', '#growthtips'],
        callToAction: 'Follow for daily creator secrets 👇',
      },
      shorts: {
        hook: 'The biggest mistake creators make daily:',
        text: 'Watch until the end to discover how to automate 10 hours a week.',
        hashtags: ['#Shorts', '#CreatorLife', '#Productivity', '#ViralTips'],
        callToAction: 'Hit subscribe for daily short-form hacks! 🔔',
      },
      reels: {
        hook: 'Stop scrolling if you want to 10x output ✨',
        text: 'Save this before your next batch creation day. Drop your thoughts below!',
        hashtags: ['#reelsvideo', '#contentcreation', '#reelsinstagram', '#creators'],
        callToAction: 'Share with a fellow creator who needs this!',
      },
    },
    viralScore: 95,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}
