import { Project, Scene, TargetPlatform, AspectRatio } from '../types';

export interface GenerateStoryboardParams {
  promptText: string;
  sourceType: 'prompt' | 'file' | 'image';
  fileName?: string;
  targetPlatform: TargetPlatform;
  aspectRatio: AspectRatio;
  pacing?: 'fast' | 'moderate' | 'cinematic';
  imageMimeType?: string;
  imageBase64?: string;
}

export async function generateStoryboard(params: GenerateStoryboardParams): Promise<{
  title: string;
  hook: string;
  scenes: Scene[];
  suggestedMusic: string;
  viralScore: number;
  captions: {
    tiktok: { text: string; hashtags: string[] };
    shorts: { text: string; hashtags: string[] };
    reels: { text: string; hashtags: string[] };
  };
}> {
  const response = await fetch('/api/gemini/generate-storyboard', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to generate storyboard: ${errorText || response.statusText}`);
  }

  const data = await response.json();

  // Normalize scenes with unique IDs and defaults
  const scenes: Scene[] = (data.scenes || []).map((s: any, idx: number) => ({
    id: `scene-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
    sceneNumber: s.sceneNumber || idx + 1,
    caption: s.caption || 'Compelling clip moment',
    voiceover: s.voiceover || s.caption || '',
    duration: Number.isFinite(Number(s.duration)) && Number(s.duration) > 0 ? Number(s.duration) : 3.0,
    transition: s.transition || 'zoom_in',
    visualDirection: s.visualDirection || 'Dynamic vertical angle',
    mediaType: params.imageBase64 && params.imageMimeType?.startsWith('image/') ? 'image' : 'color',
    mediaUrl: params.imageBase64 && params.imageMimeType?.startsWith('image/') ? `data:${params.imageMimeType || 'image/png'};base64,${params.imageBase64}` : undefined,
    accentColor: s.accentColor || ['#f43f5e', '#3b82f6', '#8b5cf6', '#10b981', '#f59e0b'][idx % 5],
    focalPoint: s.focalPoint || { x: 0.5, y: 0.5 },
    zoomScale: Number(s.zoomScale) || 1.15,
  }));

  return {
    title: data.title || 'Viral Short-Form Clip',
    hook: data.hook || 'Watch until the end...',
    scenes: scenes.length > 0 ? scenes : createDefaultScenes(params.promptText),
    suggestedMusic: data.suggestedMusic || 'Viral Phonk & Bass',
    viralScore: data.viralScore || 0,
    captions: data.captions || {
      tiktok: { text: 'Check this out!', hashtags: ['#fyp', '#viral', '#creator'] },
      shorts: { text: 'Watch until the end!', hashtags: ['#Shorts', '#CreatorLife'] },
      reels: { text: 'Save this tip!', hashtags: ['#reels', '#viralvideo'] },
    },
  };
}

export async function generateViralCaptions(params: {
  title: string;
  scriptSummary: string;
  niche?: string;
  targetPlatform?: string;
}) {
  const response = await fetch('/api/gemini/viral-captions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    throw new Error('Failed to generate viral captions');
  }

  return response.json();
}

export function createDefaultScenes(prompt?: string): Scene[] {
  const text = prompt?.trim() || 'Stop scrolling: The game-changer is here';
  return [
    {
      id: 'sc-1',
      sceneNumber: 1,
      caption: 'WAIT TILL YOU SEE THIS 🤯',
      voiceover: 'If you want to create viral short-form clips in seconds, stop what you are doing.',
      duration: 3.0,
      transition: 'zoom_in',
      visualDirection: 'Punchy eye-level hook with high contrast text',
      mediaType: 'color',
      accentColor: '#f43f5e',
      focalPoint: { x: 0.5, y: 0.45 },
      zoomScale: 1.18,
    },
    {
      id: 'sc-2',
      sceneNumber: 2,
      caption: 'STEP 1: SMART AUTOMATION',
      voiceover: 'Drop in any document, CSV, or photo. The AI detects the narrative rhythm.',
      duration: 3.2,
      transition: 'whip_pan',
      visualDirection: 'Fast push through dynamic scene highlights',
      mediaType: 'color',
      accentColor: '#3b82f6',
      focalPoint: { x: 0.48, y: 0.5 },
      zoomScale: 1.12,
    },
    {
      id: 'sc-3',
      sceneNumber: 3,
      caption: '1-CLICK EXPORT TO TIKTOK & SHORTS',
      voiceover: 'Automatic safe-zone cropping and synchronized beats ready for publishing.',
      duration: 2.8,
      transition: 'glitch',
      visualDirection: 'Vibrant highlight showcase with pulsing rhythm',
      mediaType: 'color',
      accentColor: '#8b5cf6',
      focalPoint: { x: 0.52, y: 0.48 },
      zoomScale: 1.2,
    },
    {
      id: 'sc-4',
      sceneNumber: 4,
      caption: 'TRY CLIPFLOW FREE TODAY ✨',
      voiceover: 'Save this video and level up your creator workflow now!',
      duration: 2.5,
      transition: 'fade',
      visualDirection: 'Strong call to action with closing branding',
      mediaType: 'color',
      accentColor: '#10b981',
      focalPoint: { x: 0.5, y: 0.5 },
      zoomScale: 1.05,
    },
  ];
}
