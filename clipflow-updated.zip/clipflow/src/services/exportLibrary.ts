export interface SavedExport { id: string; title: string; createdAt: number; blob?: Blob; url?: string }
function database(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('clipflow-exports', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('exports', { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function transaction<T>(mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await database();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('exports', mode);
    const request = action(tx.objectStore('exports'));
    tx.oncomplete = () => { resolve(request.result); db.close(); };
    tx.onabort = tx.onerror = () => { reject(tx.error); db.close(); };
  });
}
export const listExports = () => transaction('readonly', store => store.getAll()) as Promise<SavedExport[]>;
export const saveExport = (title: string, blob: Blob) => transaction('readwrite', store => store.put({ id: crypto.randomUUID(), title, blob, createdAt: Date.now() }));
export const saveExportReference = (title: string, url: string) => transaction('readwrite', store => store.put({ id: crypto.randomUUID(), title, url, createdAt: Date.now() }));
export async function deleteExport(id: string) {
  const item = await transaction('readonly', store => store.get(id)) as SavedExport | undefined;
  if (item?.url) {
    const response = await fetch('/api/studio/export', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: item.url }) });
    if (!response.ok && response.status !== 404) throw new Error('Could not delete the rendered file.');
  }
  return transaction('readwrite', store => store.delete(id));
}
