import { MusicVibe } from '../types';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private currentVibe: MusicVibe = 'phonk';
  private volume: number = 0.7;
  private loopInterval: number | null = null;
  private customAudio: HTMLAudioElement | null = null;
  private customAudioSrc: string | null = null;
  private destinationNode: MediaStreamAudioDestinationNode | null = null;
  private masterGain: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.volume;
      this.masterGain.connect(this.ctx.destination);
      this.destinationNode = this.ctx.createMediaStreamDestination();
      this.masterGain.connect(this.destinationNode);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getAudioStreamDestination(): MediaStreamAudioDestinationNode | null {
    this.initContext();
    return this.destinationNode;
  }

  public setVolume(volPercent: number) {
    this.volume = Math.max(0, Math.min(1, volPercent / 100));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
    if (this.customAudio) {
      this.customAudio.volume = this.volume;
    }
  }

  public setMusicVibe(vibe: MusicVibe, customUrl?: string) {
    this.currentVibe = vibe;
    if (vibe === 'custom' && customUrl) {
      this.loadCustomAudio(customUrl);
    }
  }

  public loadCustomAudio(url: string) {
    this.customAudioSrc = url;
    if (this.customAudio) {
      this.customAudio.pause();
    }
    this.customAudio = new Audio(url);
    this.customAudio.loop = true;
    this.customAudio.volume = this.volume;
  }

  public startPlayback(currentTimeSec: number = 0) {
    this.initContext();
    this.isPlaying = true;

    if (this.currentVibe === 'none') {
      return;
    }

    if (this.currentVibe === 'custom' && this.customAudio) {
      this.customAudio.currentTime = currentTimeSec % (this.customAudio.duration || 1);
      this.customAudio.play().catch(e => console.warn('Audio play prevented:', e));
      return;
    }

    this.startSynthLoop(currentTimeSec);
  }

  public stopPlayback() {
    this.isPlaying = false;
    if (this.loopInterval !== null) {
      clearInterval(this.loopInterval);
      this.loopInterval = null;
    }
    if (this.customAudio) {
      this.customAudio.pause();
    }
  }

  public seek(currentTimeSec: number) {
    if (this.customAudio) {
      this.customAudio.currentTime = currentTimeSec % (this.customAudio.duration || 1);
    }
  }

  private startSynthLoop(startOffset: number) {
    if (this.loopInterval !== null) {
      clearInterval(this.loopInterval);
    }

    // BPM and beat interval
    let bpm = 128;
    if (this.currentVibe === 'phonk') bpm = 140;
    if (this.currentVibe === 'lofi') bpm = 84;
    if (this.currentVibe === 'ambient') bpm = 60;
    if (this.currentVibe === 'acoustic') bpm = 110;

    const beatDurationMs = (60 / bpm) * 1000;
    let step = Math.floor((startOffset * 1000) / beatDurationMs) % 16;

    // Trigger initial beat
    this.playBeatStep(step);

    this.loopInterval = window.setInterval(() => {
      if (!this.isPlaying) return;
      step = (step + 1) % 16;
      this.playBeatStep(step);
    }, beatDurationMs);
  }

  private playBeatStep(step: number) {
    if (!this.ctx || !this.masterGain || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;

    switch (this.currentVibe) {
      case 'phonk':
        this.playPhonkStep(step, now);
        break;
      case 'lofi':
        this.playLofiStep(step, now);
        break;
      case 'pop':
        this.playPopStep(step, now);
        break;
      case 'ambient':
        this.playAmbientStep(step, now);
        break;
      case 'acoustic':
        this.playAcousticStep(step, now);
        break;
      default:
        break;
    }
  }

  // --- Procedural Synth Instrument Patterns ---

  private playPhonkStep(step: number, t: number) {
    // Heavy 808 Kick on 0, 4, 8, 12, with syncopated 10
    if (step === 0 || step === 4 || step === 8 || step === 10 || step === 12) {
      this.triggerKick(t, 120, 36, 0.45, 0.4);
    }
    // Snare / Clap on 4, 12
    if (step === 4 || step === 12) {
      this.triggerSnare(t, 0.25, 0.3);
    }
    // Phonk Cowbell riff (distinctive 90s Memphis tone)
    const cowbellNotes = [587.33, 659.25, 783.99, 880, 1046.5];
    if (step % 2 === 0 || step === 7 || step === 15) {
      const freq = cowbellNotes[(step * 2) % cowbellNotes.length];
      this.triggerCowbell(t, freq, 0.18, 0.2);
    }
    // Fast Hi-hats
    this.triggerHiHat(t, step % 2 === 1 ? 0.05 : 0.03, 0.12);
  }

  private playLofiStep(step: number, t: number) {
    // Warm kick on 0, 6, 10
    if (step === 0 || step === 6 || step === 10) {
      this.triggerKick(t, 90, 45, 0.3, 0.3);
    }
    // Dusty rimshot / snare on 4, 12
    if (step === 4 || step === 12) {
      this.triggerSnare(t, 0.15, 0.2);
    }
    // Jazzy Rhodes chords on 0 and 8
    if (step === 0) {
      this.triggerChord(t, [261.63, 329.63, 392.0, 493.88], 1.2, 0.15); // Cmaj7
    } else if (step === 8) {
      this.triggerChord(t, [220.0, 261.63, 329.63, 392.0], 1.2, 0.15); // Am7
    }
    // Swung Hi-hat
    if (step % 2 === 0) {
      this.triggerHiHat(t, 0.04, 0.08);
    }
  }

  private playPopStep(step: number, t: number) {
    // 4-on-the-floor kick
    if (step % 4 === 0) {
      this.triggerKick(t, 130, 50, 0.25, 0.35);
    }
    // Upbeat clap on 4 and 12
    if (step === 4 || step === 12) {
      this.triggerSnare(t, 0.2, 0.25);
    }
    // Arpeggiated upbeat synth
    const notes = [440, 554.37, 659.25, 880];
    const freq = notes[step % notes.length];
    this.triggerSynthPluck(t, freq, 0.12, 0.15);
  }

  private playAmbientStep(step: number, t: number) {
    // Gentle drone chord changes every 8 steps
    if (step === 0) {
      this.triggerChord(t, [174.61, 261.63, 329.63, 440], 2.8, 0.12); // Fmaj7
    } else if (step === 8) {
      this.triggerChord(t, [196.0, 293.66, 392.0, 493.88], 2.8, 0.12); // G6
    }
  }

  private playAcousticStep(step: number, t: number) {
    // Acoustic kick/stomp
    if (step === 0 || step === 8) {
      this.triggerKick(t, 100, 40, 0.28, 0.25);
    }
    if (step === 4 || step === 12) {
      this.triggerSnare(t, 0.12, 0.15);
    }
    // Plucked chords
    if (step % 2 === 0) {
      const acousticNotes = [329.63, 392.0, 493.88, 587.33];
      this.triggerSynthPluck(t, acousticNotes[(step / 2) % 4], 0.2, 0.14);
    }
  }

  // --- Sound Generators ---

  private triggerKick(t: number, startFreq: number, endFreq: number, decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.frequency.setValueAtTime(startFreq, t);
    osc.frequency.exponentialRampToValueAtTime(endFreq, t + decay);

    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + decay);
  }

  private triggerSnare(t: number, decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    // White noise burst
    const bufferSize = this.ctx.sampleRate * decay;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(800, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    whiteNoise.start(t);
  }

  private triggerHiHat(t: number, decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(8000, t);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(7000, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + decay);
  }

  private triggerCowbell(t: number, freq: number, decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'square';
    osc2.type = 'square';
    osc1.frequency.setValueAtTime(freq, t);
    osc2.frequency.setValueAtTime(freq * 1.48, t);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freq * 1.2, t);
    filter.Q.value = 4;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + decay);
    osc2.stop(t + decay);
  }

  private triggerSynthPluck(t: number, freq: number, decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, t);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(freq * 3, t);
    filter.frequency.exponentialRampToValueAtTime(freq, t + decay);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + decay);
  }

  private triggerChord(t: number, freqs: number[], decay: number, gainVal: number) {
    if (!this.ctx || !this.masterGain) return;
    freqs.forEach(f => {
      const osc = this.ctx!.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, t);

      const gain = this.ctx!.createGain();
      gain.gain.setValueAtTime(gainVal / freqs.length, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + decay);

      osc.connect(gain);
      gain.connect(this.masterGain!);

      osc.start(t);
      osc.stop(t + decay);
    });
  }
}

export const audioEngine = new AudioEngine();
