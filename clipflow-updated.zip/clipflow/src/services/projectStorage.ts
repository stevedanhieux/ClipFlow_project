import { Project } from '../types';

const STORAGE_KEY = 'clipflow_saved_projects';
const ACTIVE_PROJECT_KEY = 'clipflow_active_project_id';

export function getAllSavedProjects(): Project[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter(p => p && typeof p.id === "string" && Array.isArray(p.scenes) && p.scenes.every((s: any) => Number.isFinite(s.duration) && s.duration > 0)) : [];
  } catch (e) {
    console.error('Failed to parse saved projects:', e);
    return [];
  }
}

export function saveProjectToStorage(project: Project): void {
  try {
    const projects = getAllSavedProjects();
    const existingIndex = projects.findIndex(p => p.id === project.id);
    const updatedProject = { ...project, updatedAt: Date.now() };

    if (existingIndex >= 0) {
      projects[existingIndex] = updatedProject;
    } else {
      projects.unshift(updatedProject);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    localStorage.setItem(ACTIVE_PROJECT_KEY, project.id);
  } catch (e) {
    console.error('Failed to save project to localStorage:', e);
  }
}

export function deleteProjectFromStorage(id: string): Project[] {
  try {
    const projects = getAllSavedProjects().filter(p => p.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    return projects;
  } catch (e) {
    console.error('Failed to delete project:', e);
    return [];
  }
}

export function exportProjectAsJSON(project: Project): void {
  const jsonStr = JSON.stringify(project, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${project.title.replace(/[^a-zA-Z0-9_-]/g, '_')}_clipflow.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function openGoogleDriveUploadIntent(project: Project): void {
  // First download the project package
  exportProjectAsJSON(project);
  // Then open Google Drive web upload in a new tab so user can drag or save it directly
  window.open('https://drive.google.com/drive/my-drive', '_blank');
}

export async function shareVideoFile(videoBlob: Blob, title: string): Promise<boolean> {
  if (navigator.share && navigator.canShare) {
    try {
      const file = new File([videoBlob], `${title.replace(/\s+/g, '_')}.${videoBlob.type.includes('mp4') ? 'mp4' : 'webm'}`, {
        type: videoBlob.type,
      });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `ClipFlow - ${title}`,
          text: `Created with ClipFlow Studio: ${title}`,
        });
        return true;
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Web Share failed, falling back to download:', err);
      }
    }
  }
  return false;
}
