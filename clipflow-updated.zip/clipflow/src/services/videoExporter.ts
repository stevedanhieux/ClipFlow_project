import { Project, Scene, CaptionStyle } from '../types';
import { audioEngine } from './audioEngine';

export interface ExportOptions {
  resolution: '1080p' | '720p' | 'square';
  fps?: number;
  onProgress?: (progress: number, statusText: string) => void;
}

export async function exportProjectToVideo(
  project: Project,
  options: ExportOptions = { resolution: '1080p', fps: 30 }
): Promise<Blob> {
  if (!project.scenes.length) throw new Error('Add scenes before exporting.');
  if (project.scenes.some(s => s.mediaType === 'video')) throw new Error('Use Video editor / Export MP4 for imported video clips.');
  if (typeof MediaRecorder === 'undefined') throw new Error('This browser cannot record video.');
  const fps = options.fps || 30;
  const { onProgress } = options;

  // Compute dimensions
  let width = 1080;
  let height = 1920;

  if (project.aspectRatio === '1:1' || options.resolution === 'square') {
    width = 1080;
    height = 1080;
  } else if (project.aspectRatio === '16:9') {
    width = 1920;
    height = 1080;
  } else {
    // 9:16
    if (options.resolution === '720p') {
      width = 720;
      height = 1280;
    } else {
      width = 1080;
      height = 1920;
    }
  }

  if (options.resolution === '720p' && project.aspectRatio !== '9:16') { width = Math.round(width * 2 / 3); height = Math.round(height * 2 / 3); }
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) {
    throw new Error('Canvas 2D context not available for video export');
  }

  onProgress?.(5, 'Preloading visual media assets...');

  // Preload all image assets
  const loadedImages: { [sceneId: string]: HTMLImageElement } = {};
  for (const scene of project.scenes) {
    if (scene.mediaUrl) {
      try {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        await new Promise<void>((resolve, reject) => {
          img.onload = () => resolve();
          img.onerror = () => reject(new Error('Image could not be loaded')); // continue on error with color fallback
          img.src = scene.mediaUrl!;
        });
        loadedImages[scene.id] = img;
      } catch (e) {
        console.warn('Image preload error for scene:', scene.id, e);
      }
    }
  }

  onProgress?.(15, 'Initializing render stream & audio pipeline...');

  // Audio setup
  audioEngine.setMusicVibe(project.musicVibe, project.customMusicUrl);
  audioEngine.setVolume(project.musicVolume);
  const audioDestination = audioEngine.getAudioStreamDestination();

  // Video stream from canvas
  const canvasStream = canvas.captureStream(fps);
  const combinedStream = new MediaStream();

  canvasStream.getVideoTracks().forEach(track => combinedStream.addTrack(track));
  if (audioDestination && project.musicVibe !== 'none') {
    audioDestination.stream.getAudioTracks().forEach(track => combinedStream.addTrack(track));
  }

  // Determine supported mime type
  const mimeTypes = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
    'video/mp4',
  ];
  let selectedMime = mimeTypes.find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

  const recorder = new MediaRecorder(combinedStream, {
    mimeType: selectedMime,
    videoBitsPerSecond: options.resolution === '1080p' ? 8000000 : 4000000,
  });

  const chunks: Blob[] = [];
  recorder.ondataavailable = e => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };

  const totalDuration = project.scenes.reduce((acc, s) => acc + s.duration, 0);
  const totalFrames = Math.ceil(totalDuration * fps);

  // Start audio & recorder
  recorder.start(100);
  audioEngine.startPlayback(0);

  const frameIntervalMs = 1000 / fps;
  let currentFrame = 0;
  const startedAt = performance.now();
  let timer: ReturnType<typeof setTimeout>;
  const cleanup = () => { clearTimeout(timer); audioEngine.stopPlayback(); canvasStream.getTracks().forEach(t => t.stop()); };

  return new Promise((resolve, reject) => {
    recorder.onstop = () => {
      cleanup();
      const finalBlob = new Blob(chunks, { type: selectedMime });
      resolve(finalBlob);
    };

    recorder.onerror = e => {
      cleanup();
      reject(e);
    };

    // Render loop
    function renderNext() {
      if (currentFrame >= totalFrames) {
        onProgress?.(98, 'Finalizing video container...');
        setTimeout(() => recorder.stop(), 200);
        return;
      }

      const currentTimeSec = Math.min(totalDuration, (performance.now() - startedAt) / 1000);
      currentFrame = Math.floor(currentTimeSec * fps);
      try { drawFrameAtTime(ctx!, width, height, project, currentTimeSec, loadedImages); } catch (e) { cleanup(); if (recorder.state !== 'inactive') recorder.stop(); reject(e); return; }

      currentFrame++;
      const progressPercent = Math.min(95, Math.floor(15 + (currentFrame / totalFrames) * 80));
      if (currentFrame % 10 === 0 || currentFrame === totalFrames) {
        onProgress?.(progressPercent, `Rendering frame ${currentFrame} / ${totalFrames}...`);
      }

      timer = setTimeout(renderNext, frameIntervalMs);
    }

    renderNext();
  });
}

export function drawFrameAtTime(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  project: Project,
  timeSec: number,
  loadedImages: { [sceneId: string]: HTMLImageElement }
) {
  // Find active scene and progress within it
  let accumulatedTime = 0;
  let activeSceneIndex = 0;
  let sceneLocalTime = 0;

  for (let i = 0; i < project.scenes.length; i++) {
    const s = project.scenes[i];
    if (timeSec >= accumulatedTime && timeSec < accumulatedTime + s.duration) {
      activeSceneIndex = i;
      sceneLocalTime = timeSec - accumulatedTime;
      break;
    }
    accumulatedTime += s.duration;
  }

  // If time exceeds last scene
  if (timeSec >= project.scenes.reduce((sum, s) => sum + s.duration, 0) && project.scenes.length > 0) {
    activeSceneIndex = project.scenes.length - 1;
    sceneLocalTime = project.scenes[activeSceneIndex].duration;
  }

  const currentScene = project.scenes[activeSceneIndex];
  if (!currentScene) { ctx.clearRect(0, 0, width, height); return; }

  const sceneProgress = Math.min(1, Math.max(0, sceneLocalTime / currentScene.duration));
  const transitionDuration = 0.45; // transition window in seconds
  const isTransitioning = sceneLocalTime < transitionDuration && activeSceneIndex > 0;
  const prevScene = isTransitioning ? project.scenes[activeSceneIndex - 1] : null;
  const transProgress = isTransitioning ? sceneLocalTime / transitionDuration : 1;

  // Clear background
  ctx.save();
  ctx.fillStyle = '#09090b';
  ctx.fillRect(0, 0, width, height);

  // Render previous scene if in transition
  if (isTransitioning && prevScene) {
    drawSingleSceneVisual(ctx, width, height, prevScene, 1.0, loadedImages[prevScene.id]);
  }

  // Render current scene with transition effect
  ctx.save();
  applyTransitionTransform(ctx, width, height, currentScene.transition, transProgress, isTransitioning);
  drawSingleSceneVisual(ctx, width, height, currentScene, sceneProgress, loadedImages[currentScene.id]);
  ctx.restore();

  // Draw on-screen captions
  drawSceneCaptions(ctx, width, height, currentScene, project.captionStyle, sceneProgress);

  ctx.restore();
}

function drawSingleSceneVisual(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  scene: Scene,
  progress: number,
  image?: HTMLImageElement
) {
  // Ken Burns zoom & subtle pan
  const baseScale = 1.0;
  const targetScale = scene.zoomScale || 1.15;
  const currentScale = baseScale + (targetScale - baseScale) * progress;

  // Focal point pan
  const focalX = scene.focalPoint ? scene.focalPoint.x : 0.5;
  const focalY = scene.focalPoint ? scene.focalPoint.y : 0.5;
  const panOffsetX = (0.5 - focalX) * (width * 0.15) * progress;
  const panOffsetY = (0.5 - focalY) * (height * 0.15) * progress;

  ctx.save();
  ctx.translate(width / 2 + panOffsetX, height / 2 + panOffsetY);
  ctx.scale(currentScale, currentScale);
  ctx.translate(-width / 2, -height / 2);

  if (image && image.complete && image.naturalWidth > 0) {
    // Smart cover crop
    const imgAspect = image.naturalWidth / image.naturalHeight;
    const canvasAspect = width / height;

    let drawWidth = width;
    let drawHeight = height;
    let offsetX = 0;
    let offsetY = 0;

    if (imgAspect > canvasAspect) {
      drawHeight = height;
      drawWidth = height * imgAspect;
      offsetX = (width - drawWidth) * focalX;
    } else {
      drawWidth = width;
      drawHeight = width / imgAspect;
      offsetY = (height - drawHeight) * focalY;
    }

    ctx.drawImage(image, offsetX, offsetY, drawWidth, drawHeight);
  } else {
    // Sophisticated creator gradient canvas
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    const color = scene.accentColor || '#f43f5e';
    gradient.addColorStop(0, color);
    gradient.addColorStop(0.5, '#18181b');
    gradient.addColorStop(1, '#09090b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Decorative dynamic motion circles
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    const radius = Math.min(width, height) * (0.3 + progress * 0.1);
    ctx.beginPath();
    ctx.arc(width * focalX, height * focalY, radius, 0, Math.PI * 2);
    ctx.fill();

    // Subtle scene number watermark
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.font = `bold ${Math.floor(width * 0.2)}px 'Syne', sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`0${scene.sceneNumber}`, width / 2, height / 2);
  }

  ctx.restore();

  // Subtle vignette / bottom contrast scrim so captions pop
  const scrim = ctx.createLinearGradient(0, height * 0.45, 0, height);
  scrim.addColorStop(0, 'rgba(0, 0, 0, 0)');
  scrim.addColorStop(0.6, 'rgba(0, 0, 0, 0.45)');
  scrim.addColorStop(1, 'rgba(0, 0, 0, 0.85)');
  ctx.fillStyle = scrim;
  ctx.fillRect(0, height * 0.45, width, height * 0.55);
}

function applyTransitionTransform(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  transition: string,
  progress: number,
  isTransitioning: boolean
) {
  if (!isTransitioning) return;

  switch (transition) {
    case 'fade':
      ctx.globalAlpha = Math.max(0, Math.min(1, progress));
      break;

    case 'zoom_in':
      const zoom = 0.8 + 0.2 * progress;
      ctx.translate(width / 2, height / 2);
      ctx.scale(zoom, zoom);
      ctx.translate(-width / 2, -height / 2);
      ctx.globalAlpha = Math.max(0, Math.min(1, progress));
      break;

    case 'zoom_out':
      const zoomOut = 1.25 - 0.25 * progress;
      ctx.translate(width / 2, height / 2);
      ctx.scale(zoomOut, zoomOut);
      ctx.translate(-width / 2, -height / 2);
      ctx.globalAlpha = Math.max(0, Math.min(1, progress));
      break;

    case 'slide_left':
      const offsetX = (1 - progress) * width;
      ctx.translate(offsetX, 0);
      break;

    case 'whip_pan':
      const whipX = (1 - Math.sin((progress * Math.PI) / 2)) * width * 0.6;
      ctx.translate(whipX, 0);
      ctx.globalAlpha = Math.max(0.2, progress);
      break;

    case 'glitch':
      if (progress < 0.8) {
        const jitter = (Math.random() - 0.5) * 24 * (1 - progress);
        ctx.translate(jitter, 0);
      }
      ctx.globalAlpha = progress > 0.3 ? 1 : 0.4;
      break;

    case 'flash':
      ctx.globalAlpha = Math.max(0, Math.min(1, progress));
      // White burst overlay
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0, 1 - progress * 2)})`;
      ctx.fillRect(0, 0, width, height);
      break;

    default:
      ctx.globalAlpha = Math.max(0, Math.min(1, progress));
      break;
  }
}

function drawSceneCaptions(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  scene: Scene,
  style: CaptionStyle,
  progress: number
) {
  const text = (scene.caption || '').trim().toUpperCase();
  if (!text) return;

  const words = text.split(/\s+/);
  const baseY = height * 0.68; // Safe zone: above TikTok description & buttons
  const fontSize = Math.floor(width * 0.058);

  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Pop-in scale on scene entrance
  const entranceProgress = Math.min(1, progress * 4);
  const textScale = 0.9 + 0.1 * entranceProgress;
  ctx.translate(width / 2, baseY);
  ctx.scale(textScale, textScale);
  ctx.translate(-width / 2, -baseY);

  switch (style) {
    case 'tiktok_yellow': {
      // Signature bold viral yellow text with thick black outline
      ctx.font = `900 ${fontSize}px 'Syne', sans-serif`;

      // Word wrapping
      const maxWidth = width * 0.82;
      const lines = wrapText(ctx, text, maxWidth);
      const lineHeight = fontSize * 1.25;
      const startY = baseY - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, idx) => {
        const y = startY + idx * lineHeight;
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = Math.max(6, Math.floor(fontSize * 0.22));
        ctx.lineJoin = 'miter';
        ctx.miterLimit = 2;
        ctx.strokeText(line, width / 2, y);

        ctx.fillStyle = '#ffdf00'; // Viral TikTok yellow
        ctx.fillText(line, width / 2, y);
      });
      break;
    }

    case 'classic_box': {
      // Clean modern pill box
      ctx.font = `700 ${fontSize * 0.88}px 'Plus Jakarta Sans', sans-serif`;
      const maxWidth = width * 0.8;
      const lines = wrapText(ctx, text, maxWidth);
      const lineHeight = fontSize * 1.3;
      const totalBoxHeight = lines.length * lineHeight + 24;
      const startY = baseY - ((lines.length - 1) * lineHeight) / 2;

      // Draw background rounded box
      ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
      const boxWidth = Math.min(width * 0.88, width * 0.82);
      roundRect(ctx, width / 2 - boxWidth / 2, baseY - totalBoxHeight / 2, boxWidth, totalBoxHeight, 14);
      ctx.fill();

      lines.forEach((line, idx) => {
        const y = startY + idx * lineHeight;
        ctx.fillStyle = '#ffffff';
        ctx.fillText(line, width / 2, y);
      });
      break;
    }

    case 'karaoke': {
      // Word by word highlight
      ctx.font = `800 ${fontSize * 0.95}px 'Syne', sans-serif`;
      const wordsCount = words.length;
      const currentActiveIndex = Math.min(wordsCount - 1, Math.floor(progress * wordsCount));

      // Draw single line or simple wrap
      const maxWidth = width * 0.84;
      const lines = wrapText(ctx, text, maxWidth);
      const lineHeight = fontSize * 1.28;
      const startY = baseY - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, idx) => {
        const y = startY + idx * lineHeight;
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.8)';
        ctx.lineWidth = 5;
        ctx.strokeText(line, width / 2, y);

        // Highlight active word
        ctx.fillStyle = idx === Math.floor(currentActiveIndex / 3) ? '#38bdf8' : '#ffffff';
        ctx.fillText(line, width / 2, y);
      });
      break;
    }

    case 'minimal_clean':
    default: {
      ctx.font = `600 ${fontSize * 0.8}px 'Plus Jakarta Sans', sans-serif`;
      const maxWidth = width * 0.84;
      const lines = wrapText(ctx, text, maxWidth);
      const lineHeight = fontSize * 1.2;
      const startY = baseY - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, idx) => {
        const y = startY + idx * lineHeight;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 12;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 2;
        ctx.fillStyle = '#ffffff';
        ctx.fillText(line, width / 2, y);
      });
      break;
    }
  }

  ctx.restore();
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = words[0] || '';

  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const width = ctx.measureText(currentLine + ' ' + word).width;
    if (width < maxWidth) {
      currentLine += ' ' + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);
  return lines;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}
