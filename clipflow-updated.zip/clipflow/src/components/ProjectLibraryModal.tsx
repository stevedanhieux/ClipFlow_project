import React, { useRef } from 'react';
import {
  X,
  FolderOpen,
  Plus,
  Trash2,
  Download,
  Upload,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { Project } from '../types';
import { exportProjectAsJSON } from '../services/projectStorage';

interface ProjectLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedProjects: Project[];
  activeProjectId: string;
  onSelectProject: (project: Project) => void;
  onDeleteProject: (projectId: string) => void;
  onNewProject: () => void;
  onImportProject: (project: Project) => void;
}

export const ProjectLibraryModal: React.FC<ProjectLibraryModalProps> = ({
  isOpen,
  onClose,
  savedProjects,
  activeProjectId,
  onSelectProject,
  onDeleteProject,
  onNewProject,
  onImportProject,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = ev => {
        try {
          const parsed = JSON.parse(ev.target?.result as string);
          if (parsed && parsed.scenes && parsed.id) {
            onImportProject(parsed);
          }
        } catch (err) {
          console.error('Invalid JSON project file:', err);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-rose-600" />
            <span className="font-display font-bold text-lg text-zinc-900 dark:text-zinc-100">
              Saved Video Projects
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onNewProject}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer min-h-[38px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Project List */}
        <div className="p-6 space-y-3 overflow-y-auto flex-1">
          {savedProjects.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <FolderOpen className="w-10 h-10 text-zinc-300 dark:text-zinc-700 mx-auto" />
              <p className="text-sm text-zinc-500">No saved projects yet. Your work auto-saves here!</p>
              <button
                onClick={onNewProject}
                className="px-4 py-2 text-xs font-semibold bg-rose-600 text-white rounded-xl shadow-sm cursor-pointer"
              >
                Create First Video
              </button>
            </div>
          ) : (
            savedProjects.map(proj => {
              const isActive = proj.id === activeProjectId;
              const totalSec = proj.scenes.reduce((acc, s) => acc + s.duration, 0);

              return (
                <div
                  key={proj.id}
                  onClick={() => onSelectProject(proj)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isActive
                      ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/20 shadow-sm'
                      : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/30 hover:border-zinc-300'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 truncate max-w-xs">
                        {proj.title}
                      </span>
                      {isActive && (
                        <span className="text-[10px] font-bold text-rose-600 bg-rose-100 dark:bg-rose-950/60 px-2 py-0.5 rounded-full">
                          Current
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                      <span>{proj.scenes.length} Scenes</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-nums">{totalSec.toFixed(1)}s</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{proj.targetPlatform}</span>
                      <span aria-hidden="true">·</span>
                      <span>{new Date(proj.updatedAt || proj.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
                    <button
                      onClick={() => exportProjectAsJSON(proj)}
                      title="Download JSON Project Backup"
                      className="p-2 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    {savedProjects.length > 1 && (
                      <button
                        onClick={() => onDeleteProject(proj.id)}
                        title="Delete project"
                        className="p-2 rounded-lg text-zinc-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with JSON File Import option */}
        <div className="px-6 py-3 border-t border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50 flex items-center justify-between">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleFileImport}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 transition-colors cursor-pointer min-h-[40px]"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import Project JSON</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:bg-zinc-800 transition-colors cursor-pointer min-h-[40px]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
