import React, { useState, useRef, DragEvent } from 'react';
import {
  UploadCloud,
  FileText,
  Image as ImageIcon,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertCircle,
  X,
  FileSpreadsheet,
  FileCode,
} from 'lucide-react';
import { TargetPlatform, AspectRatio } from '../types';

interface InputSectionProps {
  onGenerate: (data: {
    promptText: string;
    sourceType: 'prompt' | 'file' | 'image';
    fileName?: string;
    targetPlatform: TargetPlatform;
    aspectRatio: AspectRatio;
    pacing: 'fast' | 'moderate' | 'cinematic';
    imageMimeType?: string;
    imageBase64?: string;
  }) => Promise<void>;
  isGenerating: boolean;
  targetPlatform: TargetPlatform;
  setTargetPlatform: (platform: TargetPlatform) => void;
  aspectRatio: AspectRatio;
  setAspectRatio: (ratio: AspectRatio) => void;
}

export const InputSection: React.FC<InputSectionProps> = ({
  onGenerate,
  isGenerating,
  targetPlatform,
  setTargetPlatform,
  aspectRatio,
  setAspectRatio,
}) => {
  const [promptText, setPromptText] = useState('');
  const [pacing, setPacing] = useState<'fast' | 'moderate' | 'cinematic'>('fast');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: number;
    type: string;
    content?: string;
    previewUrl?: string;
    base64?: string;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const samplePrompts = [
    '3 productivity habits that saved me 10 hours this week',
    'Why you should stop scrolling and start publishing today',
    'Top 3 secret features in this tech tool you never knew',
    'Quick healthy 15-minute high protein meal prep',
  ];

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = async (file: File) => {
    setErrorMessage(null);
    const fileName = file.name;
    const fileType = file.type;

    if (file.size > 20 * 1024 * 1024) { setErrorMessage('Use files under 20 MB for slide generation. Import large video files in the Video editor.'); return; }
    if (fileName.toLowerCase().endsWith('.pdf')) {
      const reader = new FileReader();
      reader.onerror = () => setErrorMessage('Could not read this PDF.');
      reader.onload = () => setUploadedFile({ name: fileName, size: file.size, type: 'application/pdf', base64: String(reader.result).split(',')[1] });
      reader.readAsDataURL(file); return;
    }
    // Image file handling (Image-to-Video)
    if (fileType.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = e => {
        const result = e.target?.result as string;
        const base64Data = result.split(',')[1];
        setUploadedFile({
          name: fileName,
          size: file.size,
          type: fileType,
          previewUrl: result,
          base64: base64Data,
        });
        if (!promptText) {
          setPromptText(`Turn this image into an engaging short-form video clip showcasing key visual highlights.`);
        }
      };
      reader.onerror = () => setErrorMessage('Could not read this image.');
      reader.readAsDataURL(file);
      return;
    }

    // PDF, CSV, TXT, MD, JSON text extraction
    const reader = new FileReader();
    reader.onload = e => {
      let text = (e.target?.result as string) || '';

      if (fileName.endsWith('.csv')) {
        const rows = text.split('\n').filter(r => r.trim().length > 0);
        text = `CSV Data Summary (${rows.length} rows):\n` + rows.slice(0, 15).join('\n');
      }

      setUploadedFile({
        name: fileName,
        size: file.size,
        type: fileType || 'text/plain',
        content: text.slice(0, 4000),
      });

      if (!promptText) {
        setPromptText(text.slice(0, 800));
      }
    };

    reader.onerror = () => setErrorMessage('Could not read this file.');
    reader.readAsText(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptText.trim() && !uploadedFile) {
      setErrorMessage('Please enter a prompt or drop a file / image to get started.');
      return;
    }

    setErrorMessage(null);
    try {
      await onGenerate({
        promptText: promptText.trim() || (uploadedFile?.content ? uploadedFile.content : 'Create a short-form clip'),
        sourceType: uploadedFile?.previewUrl ? 'image' : uploadedFile ? 'file' : 'prompt',
        fileName: uploadedFile?.name,
        targetPlatform,
        aspectRatio,
        pacing,
        imageMimeType: uploadedFile?.type,
        imageBase64: uploadedFile?.base64,
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Error generating storyboard. Please try again.');
    }
  };

  const clearFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Intro Header */}
      <div className="text-center space-y-2">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight">
          Create Viral Clips in Seconds
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 max-w-xl mx-auto">
          Drop any script, image, CSV or PDF. ClipFlow automatically crafts scenes, transitions, music, and viral captions.
        </p>
      </div>

      {/* Target Platform Selector (Interactive Segmented Control) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
          <span className="font-medium">Output Platform</span>
          <span>Optimized safe zones & pacing</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { id: 'tiktok', name: 'TikTok', tag: 'Fast Hook · 9:16', desc: 'Snappy edits & high retention' },
            { id: 'shorts', name: 'YouTube Shorts', tag: 'Curiosity · 9:16', desc: 'Retention spikes & title cards' },
            { id: 'reels', name: 'Instagram Reels', tag: 'Aesthetic · 9:16', desc: 'Clean layout & visual polish' },
            { id: 'cross_platform', name: 'Cross-Platform', tag: 'Universal · 9:16', desc: 'Optimized for all channels' },
          ].map(p => {
            const isActive = targetPlatform === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setTargetPlatform(p.id as TargetPlatform)}
                className={`flex flex-col p-3 rounded-xl border text-left transition-all cursor-pointer min-h-[56px] ${
                  isActive
                    ? 'border-rose-600 bg-rose-50/70 dark:bg-rose-950/30 text-rose-900 dark:text-rose-200 shadow-sm'
                    : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-semibold">{p.name}</span>
                  {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                </div>
                <span className="text-[11px] opacity-75 mt-0.5">{p.tag}</span>
              </button>
            );
          })}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Drag and Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center transition-all cursor-pointer ${
            isDragging
              ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/20 scale-[0.99]'
              : uploadedFile
              ? 'border-emerald-500/80 bg-emerald-50/20 dark:bg-emerald-950/10'
              : 'border-zinc-300 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50 hover:border-zinc-400 dark:hover:border-zinc-700'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.csv,.pdf,.json,.md,.png,.jpg,.jpeg,.webp,.svg,.gif"
            onChange={handleFileSelect}
            className="hidden"
          />

          {uploadedFile ? (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
              <div className="flex items-center gap-3">
                {uploadedFile.previewUrl ? (
                  <img
                    src={uploadedFile.previewUrl}
                    alt="Uploaded preview"
                    className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-xl border border-zinc-200 dark:border-zinc-700 shrink-0"
                  />
                ) : uploadedFile.name.endsWith('.csv') ? (
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="w-6 h-6" />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center shrink-0">
                    <FileText className="w-6 h-6" />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 truncate max-w-[200px] sm:max-w-xs">
                      {uploadedFile.name}
                    </span>
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">Ready</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                    <span>{(uploadedFile.size / 1024).toFixed(1)} KB</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {uploadedFile.previewUrl
                        ? 'Image-to-Video Mode'
                        : 'Document Auto-Parsed'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    clearFile();
                  }}
                  className="px-3 py-1.5 text-xs text-zinc-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1 min-h-[44px]"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Remove file</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="w-12 h-12 mx-auto rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 flex items-center justify-center">
                <UploadCloud className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                  Drag & drop your file or photo here, or click to browse
                </p>
                <div className="flex items-center justify-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                  <span>PNG, JPG, WebP</span>
                  <span aria-hidden="true">·</span>
                  <span>TXT, CSV, PDF, MD</span>
                  <span aria-hidden="true">·</span>
                  <span>Up to 25MB</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Text Prompt or Script Input */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
            <label htmlFor="promptInput" className="font-medium text-zinc-700 dark:text-zinc-300">
              {uploadedFile?.previewUrl
                ? 'Video Vision / Instructions for this Photo'
                : 'Video Script or Topic Prompt'}
            </label>
            <span>Gemini AI Director</span>
          </div>
          <div className="relative">
            <textarea
              id="promptInput"
              rows={4}
              value={promptText}
              onChange={e => setPromptText(e.target.value)}
              placeholder={
                uploadedFile?.previewUrl
                  ? 'Describe how to animate and narrate this photo (e.g. "Create a 15-second product launch clip highlighting modern design and benefits")...'
                  : 'Enter your rough idea, raw script, bullet points, or paste an article snippet...'
              }
              className="w-full p-3 sm:p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-rose-500 text-sm leading-relaxed"
            />
          </div>

          {/* Quick Starter Inspiration Prompts */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] text-zinc-400 dark:text-zinc-500 font-medium">Quick Inspiration:</span>
            <div className="flex flex-wrap gap-1.5">
              {samplePrompts.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setPromptText(p)}
                  className="text-xs px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors text-left truncate max-w-full"
                >
                  "{p}"
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Aspect Ratio & Pacing Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          {/* Aspect Ratio */}
          <div className="space-y-1.5">
            <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Aspect Ratio</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '9:16', label: '9:16 Vertical', sub: 'TikTok/Reels' },
                { id: '1:1', label: '1:1 Square', sub: 'Instagram/Feed' },
                { id: '16:9', label: '16:9 Wide', sub: 'YouTube' },
              ].map(ar => (
                <button
                  key={ar.id}
                  type="button"
                  onClick={() => setAspectRatio(ar.id as AspectRatio)}
                  className={`py-2 px-2 rounded-lg border text-center transition-all min-h-[44px] cursor-pointer ${
                    aspectRatio === ar.id
                      ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-semibold'
                      : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:border-zinc-300'
                  }`}
                >
                  <div className="text-xs">{ar.label}</div>
                  <div className="text-[10px] opacity-70">{ar.sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Pacing */}
          <div className="space-y-1.5">
            <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Editing Pacing</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'fast', label: 'Fast Paced', sub: '~2.5s cuts' },
                { id: 'moderate', label: 'Standard', sub: '~3.2s cuts' },
                { id: 'cinematic', label: 'Cinematic', sub: '~4.0s cuts' },
              ].map(pc => (
                <button
                  key={pc.id}
                  type="button"
                  onClick={() => setPacing(pc.id as any)}
                  className={`py-2 px-2 rounded-lg border text-center transition-all min-h-[44px] cursor-pointer ${
                    pacing === pc.id
                      ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-semibold'
                      : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:border-zinc-300'
                  }`}
                >
                  <div className="text-xs">{pc.label}</div>
                  <div className="text-[10px] opacity-70">{pc.sub}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="flex items-center gap-2 p-3 text-xs text-rose-700 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-300 rounded-xl border border-rose-200 dark:border-rose-800">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Generate CTA Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isGenerating}
            className="w-full py-3.5 px-6 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-rose-600/20 active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer min-h-[48px]"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>AI Directing Storyboard & Scenes...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>
                  {uploadedFile?.previewUrl
                    ? 'Turn Photo into Short-Form Video'
                    : 'Generate Video Storyboard with Gemini'}
                </span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
