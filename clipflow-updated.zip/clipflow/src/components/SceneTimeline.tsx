import React from 'react';
import { Plus, ChevronLeft, ChevronRight, Copy, Trash2, Edit3, Sparkles } from 'lucide-react';
import { Project, Scene, TransitionType } from '../types';

interface SceneTimelineProps {
  project: Project;
  onUpdateProject: (updated: Project) => void;
  currentTime: number;
  onSeekToScene: (sceneIndex: number) => void;
  onOpenSceneInspector: (scene: Scene) => void;
}

export const SceneTimeline: React.FC<SceneTimelineProps> = ({
  project,
  onUpdateProject,
  currentTime,
  onSeekToScene,
  onOpenSceneInspector,
}) => {
  // Find currently active scene index
  let accumulated = 0;
  let activeIndex = 0;
  for (let i = 0; i < project.scenes.length; i++) {
    if (currentTime >= accumulated && currentTime < accumulated + project.scenes[i].duration) {
      activeIndex = i;
      break;
    }
    accumulated += project.scenes[i].duration;
  }

  const handleMoveScene = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= project.scenes.length) return;

    const newScenes = [...project.scenes];
    const temp = newScenes[index];
    newScenes[index] = newScenes[targetIndex];
    newScenes[targetIndex] = temp;

    // Renumber
    newScenes.forEach((s, idx) => (s.sceneNumber = idx + 1));
    onUpdateProject({ ...project, scenes: newScenes });
  };

  const handleDuplicateScene = (index: number) => {
    const sceneToDup = project.scenes[index];
    const newScene: Scene = {
      ...sceneToDup,
      id: `scene-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      caption: `${sceneToDup.caption} (Copy)`,
    };
    const newScenes = [...project.scenes];
    newScenes.splice(index + 1, 0, newScene);
    newScenes.forEach((s, idx) => (s.sceneNumber = idx + 1));
    onUpdateProject({ ...project, scenes: newScenes });
  };

  const handleDeleteScene = (index: number) => {
    if (project.scenes.length <= 1) return;
    const newScenes = project.scenes.filter((_, idx) => idx !== index);
    newScenes.forEach((s, idx) => (s.sceneNumber = idx + 1));
    onUpdateProject({ ...project, scenes: newScenes });
  };

  const handleAddScene = () => {
    const lastScene = project.scenes[project.scenes.length - 1];
    const newScene: Scene = {
      id: `scene-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sceneNumber: project.scenes.length + 1,
      caption: 'NEXT VIRAL MOMENT',
      voiceover: 'Keep the audience engaged with a sudden twist or high-value takeaway.',
      duration: 3.0,
      transition: 'zoom_in',
      visualDirection: 'Dynamic punch in',
      mediaType: 'color',
      accentColor: ['#f43f5e', '#3b82f6', '#8b5cf6', '#10b981', '#f59e0b'][project.scenes.length % 5],
      focalPoint: { x: 0.5, y: 0.5 },
      zoomScale: 1.15,
    };
    onUpdateProject({ ...project, scenes: [...project.scenes, newScene] });
  };

  const totalDuration = project.scenes.reduce((acc, s) => acc + s.duration, 0);

  return (
    <div className="w-full space-y-3">
      {/* Header bar */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
            Scene Timeline
          </span>
          <span className="text-xs text-zinc-400">·</span>
          <span className="text-xs text-zinc-500 font-mono-nums">
            {project.scenes.length} Scenes ({totalDuration.toFixed(1)}s total)
          </span>
        </div>

        <button
          onClick={handleAddScene}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer min-h-[38px]"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Scene</span>
        </button>
      </div>

      {/* Horizontal Scrollable Timeline Track */}
      <div className="flex items-stretch gap-3 overflow-x-auto pb-3 pt-1 scroll-smooth snap-x">
        {project.scenes.map((scene, idx) => {
          const isActive = idx === activeIndex;

          return (
            <div
              key={scene.id}
              onClick={() => onSeekToScene(idx)}
              className={`snap-start shrink-0 w-44 sm:w-48 p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between select-none relative group ${
                isActive
                  ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/20 shadow-md ring-2 ring-rose-500/20'
                  : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 hover:border-zinc-300 dark:hover:border-zinc-700'
              }`}
            >
              {/* Scene Number & Duration badge */}
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-display font-bold text-zinc-900 dark:text-zinc-100">
                  0{scene.sceneNumber}
                </span>
                <span className="text-[11px] font-mono-nums text-zinc-500 dark:text-zinc-400">
                  {scene.duration.toFixed(1)}s
                </span>
              </div>

              {/* Visual Thumbnail Preview or Gradient Block */}
              <div
                className="w-full h-20 rounded-xl overflow-hidden relative border border-black/10 dark:border-white/10 mb-2 flex items-center justify-center"
                style={{
                  background: scene.mediaUrl
                    ? `url(${scene.mediaUrl}) center/cover no-repeat`
                    : scene.accentColor || '#f43f5e',
                }}
              >
                {!scene.mediaUrl && (
                  <span className="font-display text-2xl font-bold text-white/30">
                    {scene.sceneNumber}
                  </span>
                )}
                {/* Transition Tag */}
                <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/60 backdrop-blur-sm text-[9px] text-white/90 font-mono-nums capitalize">
                  {scene.transition.replace('_', ' ')}
                </div>
              </div>

              {/* Caption Preview Text */}
              <div className="text-[11px] font-semibold text-zinc-800 dark:text-zinc-200 line-clamp-2 min-h-[32px]">
                {scene.caption || 'Empty caption'}
              </div>

              {/* Action Toolbar on Bottom */}
              <div
                className="flex items-center justify-between pt-2 border-t border-zinc-100 dark:border-zinc-800 mt-2"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center gap-0.5">
                  <button
                    disabled={idx === 0}
                    onClick={() => handleMoveScene(idx, 'left')}
                    title="Move left"
                    className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    disabled={idx === project.scenes.length - 1}
                    onClick={() => handleMoveScene(idx, 'right')}
                    title="Move right"
                    className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleDuplicateScene(idx)}
                    title="Duplicate scene"
                    className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenSceneInspector(scene)}
                    title="Edit scene properties"
                    className="p-1 rounded text-zinc-500 hover:text-rose-600 dark:hover:text-rose-400 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  {project.scenes.length > 1 && (
                    <button
                      onClick={() => handleDeleteScene(idx)}
                      title="Delete scene"
                      className="p-1 rounded text-zinc-400 hover:text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Add Scene Card at end of timeline */}
        <button
          onClick={handleAddScene}
          className="snap-start shrink-0 w-32 p-4 rounded-2xl border-2 border-dashed border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 flex flex-col items-center justify-center gap-2 text-zinc-500 hover:text-rose-600 transition-colors cursor-pointer min-h-[160px]"
        >
          <div className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center">
            <Plus className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold">New Scene</span>
        </button>
      </div>
    </div>
  );
};
