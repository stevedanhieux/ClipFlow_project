import React from 'react';
import { Sparkles, Sun, Moon, Download, FolderOpen, Plus } from 'lucide-react';

interface HeaderProps {
  activeTab: 'studio' | 'input' | 'ai' | 'projects' | 'editor';
  setActiveTab: (tab: 'studio' | 'input' | 'ai' | 'projects' | 'editor') => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  onOpenExport: () => void;
  onNewProject: () => void;
  projectTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  theme,
  setTheme,
  onOpenExport,
  onNewProject,
  projectTitle,
}) => {
  return (
    <header className="sticky top-0 z-30 w-full border-b transition-colors bg-white/90 dark:bg-zinc-950/90 backdrop-blur-md border-zinc-200 dark:border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single Text Element Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="/"
            onClick={e => {
              e.preventDefault();
              setActiveTab('studio');
            }}
            className="flex items-center gap-2 group cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-rose-600 flex items-center justify-center text-white shadow-sm shadow-rose-600/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-display text-xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100">
              ClipFlow
            </span>
          </a>

          {/* Quiet text kicker for active project title on desktop */}
          <span className="hidden lg:inline text-xs text-zinc-400 dark:text-zinc-500 font-mono-nums truncate max-w-[200px]">
            {projectTitle}
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setActiveTab('studio')}
            className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] cursor-pointer ${
              activeTab === 'studio'
                ? 'bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Studio Editor
          </button>
          <button
            onClick={() => setActiveTab('input')}
            className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] cursor-pointer ${
              activeTab === 'input'
                ? 'bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Import & Direct
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] cursor-pointer ${
              activeTab === 'ai'
                ? 'bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Viral AI Suite
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] cursor-pointer ${
              activeTab === 'projects'
                ? 'bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Saved Projects
          </button>
        </nav>

        {/* Zone 3: Primary Actions & Theme */}
        <div className="flex items-center gap-2">
          {/* Theme Toggle */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-zinc-700" />}
          </button>

          {/* New Project Quick Action (Desktop) */}
          <button
            onClick={onNewProject}
            title="Create new video clip"
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors min-h-[40px] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New</span>
          </button>

          {/* Primary Export Button */}
          <button
            onClick={onOpenExport}
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 active:scale-[0.98] rounded-lg transition-all shadow-sm shadow-rose-600/30 whitespace-nowrap min-h-[40px] cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Clip</span>
          </button>
        </div>
      </div>
    </header>
  );
};
