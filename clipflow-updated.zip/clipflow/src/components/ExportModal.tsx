import { ExportLibrary } from './ExportLibrary';
import { saveExport } from '../services/exportLibrary';
import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Share2,
  Cloud,
  CheckCircle2,
  Sparkles,
  Film,
  HardDrive,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Project } from '../types';
import { exportProjectToVideo } from '../services/videoExporter';
import { openGoogleDriveUploadIntent, shareVideoFile, saveProjectToStorage } from '../services/projectStorage';

interface ExportModalProps {
  project: Project;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ project, isOpen, onClose }) => {
  const [resolution, setResolution] = useState<'1080p' | '720p' | 'square'>('1080p');
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');
  const [renderedBlob, setRenderedBlob] = useState<Blob | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  const [refresh, setRefresh] = useState(0);
  useEffect(() => () => { if (downloadUrl) URL.revokeObjectURL(downloadUrl); }, [downloadUrl]);
  useEffect(() => { setRenderedBlob(null); setDownloadUrl(null); setStatusText(''); }, [project]);
  if (!isOpen) return null;

  const handleStartExport = async () => {
    setIsExporting(true);
    setProgress(5);
    setStatusText('Preparing canvas renderer...');
    setRenderedBlob(null);

    try {
      // Auto-save project state to storage
      saveProjectToStorage(project);

      const blob = await exportProjectToVideo(project, {
        resolution,
        fps: 30,
        onProgress: (pct, msg) => {
          setProgress(pct);
          setStatusText(msg);
        },
      });

      try { await saveExport(project.title, blob); setRefresh(r => r + 1); } catch { setStatusText('Rendered, but browser storage is full. Download this video to keep it.'); }
      setRenderedBlob(blob);
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);

      // Trigger celebration
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      console.error('Export failed:', err);
      setStatusText(err.message || 'Export failed. Please retry.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = () => {
    if (!downloadUrl) return;
    const a = document.createElement('a');
    a.href = downloadUrl;
    const ext = renderedBlob?.type.includes('mp4') ? 'mp4' : 'webm';
    a.download = `${project.title.replace(/[^a-zA-Z0-9_-]/g, '_')}_${resolution}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    if (!renderedBlob) return;
    const shared = await shareVideoFile(renderedBlob, project.title);
    if (!shared) {
      handleDownload();
    }
  };

  const handleGoogleDriveSave = () => {
    openGoogleDriveUploadIntent(project);
    if (downloadUrl) {
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-y-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-rose-600" />
            <span className="font-display font-bold text-lg text-zinc-900 dark:text-zinc-100">
              Export Video
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <ExportLibrary refresh={refresh} />
        {/* Modal Content */}
        <div className="p-6 space-y-6">
          {statusText && !isExporting && <p role="status" className="text-sm text-rose-500">{statusText}</p>}
          {!renderedBlob && !isExporting && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  Select Export Quality
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: '1080p', label: '1080p Full HD', desc: '1080x1920 · TikTok' },
                    { id: '720p', label: '720p Fast', desc: '720x1280 · Rapid' },
                    { id: 'square', label: '1080p Square', desc: '1080x1080 · IG Feed' },
                  ].map(res => (
                    <button
                      key={res.id}
                      type="button"
                      onClick={() => setResolution(res.id as any)}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer min-h-[52px] ${
                        resolution === res.id
                          ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold'
                          : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/40 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300'
                      }`}
                    >
                      <div className="text-xs">{res.label}</div>
                      <div className="text-[10px] opacity-70 mt-0.5">{res.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Summary Stats */}
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 space-y-2 text-xs">
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Scenes:</span>
                  <span className="font-semibold text-zinc-900 dark:text-zinc-100">{project.scenes.length}</span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Total Duration:</span>
                  <span className="font-semibold text-zinc-900 dark:text-zinc-100 font-mono-nums">
                    {project.scenes.reduce((acc, s) => acc + s.duration, 0).toFixed(1)}s
                  </span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Audio Sync:</span>
                  <span className="font-semibold text-zinc-900 dark:text-zinc-100 capitalize">{project.musicVibe}</span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Captions:</span>
                  <span className="font-semibold text-zinc-900 dark:text-zinc-100 capitalize">
                    {project.captionStyle.replace('_', ' ')}
                  </span>
                </div>
              </div>

              <button
                onClick={handleStartExport}
                className="w-full py-3.5 px-6 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99] min-h-[48px]"
              >
                <Sparkles className="w-4 h-4" />
                <span>Start Video Render</span>
              </button>
            </div>
          )}

          {/* Rendering Progress View */}
          {isExporting && (
            <div className="py-8 space-y-5 text-center">
              <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
                <div className="w-20 h-20 border-4 border-zinc-200 dark:border-zinc-800 border-t-rose-600 rounded-full animate-spin" />
                <span className="absolute font-mono-nums font-bold text-sm text-zinc-900 dark:text-zinc-100">
                  {progress}%
                </span>
              </div>

              <div className="space-y-1">
                <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                  Rendering High-Definition Frames
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono-nums">
                  {statusText || 'Processing composite layers...'}
                </p>
              </div>

              <div className="w-full bg-zinc-100 dark:bg-zinc-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-rose-600 h-2 rounded-full transition-all duration-150"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Render Complete View */}
          {renderedBlob && !isExporting && (
            <div className="space-y-5 text-center">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-zinc-100">
                  Video Rendered Successfully!
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Size: {(renderedBlob.size / (1024 * 1024)).toFixed(2)} MB · Ready to share on social channels
                </p>
              </div>

              {/* Video Preview Player */}
              {downloadUrl && (
                <div className="rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-700 bg-black max-h-48 flex items-center justify-center">
                  <video src={downloadUrl} controls className="max-h-48 w-auto rounded-xl" autoPlay loop muted />
                </div>
              )}

              {/* Actions Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                {/* 1. Direct Download */}
                <button
                  onClick={handleDownload}
                  className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer min-h-[44px]"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Video</span>
                </button>

                {/* 2. Web Share API */}
                <button
                  onClick={handleShare}
                  className="py-3 px-4 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer min-h-[44px]"
                >
                  <Share2 className="w-4 h-4 text-zinc-500" />
                  <span>Share to Apps</span>
                </button>

                {/* 3. Google Drive / Cloud Backup */}
                <button
                  onClick={handleGoogleDriveSave}
                  title="Save package and open Google Drive"
                  className="py-3 px-4 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer min-h-[44px]"
                >
                  <Cloud className="w-4 h-4 text-blue-500" />
                  <span>Google Drive</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
