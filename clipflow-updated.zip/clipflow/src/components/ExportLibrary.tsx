import React, { useEffect, useState } from 'react';
import { listExports, deleteExport, SavedExport } from '../services/exportLibrary';
export function ExportLibrary({ refresh }: { refresh: number }) {
  const [items, setItems] = useState<SavedExport[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [error, setError] = useState('');
  const reload = () => listExports().then(setItems).catch(e => setError(String(e)));
  useEffect(() => { reload(); }, [refresh]);
  const remove = async (ids: string[]) => {
    if (!window.confirm(`Delete ${ids.length} saved export(s)? Downloaded files are kept.`)) return;
    try { for (const id of ids) await deleteExport(id); setSelected([]); await reload(); }
    catch (e) { setError(String(e)); }
  };
  return <section className="p-4 border-t border-zinc-700 space-y-3 text-sm">
    <h3 className="font-bold">Saved exports</h3>
    <div className="flex gap-3 flex-wrap">
      <label><input type="checkbox" aria-label="Select all exports" checked={items.length > 0 && selected.length === items.length} onChange={e => setSelected(e.target.checked ? items.map(i => i.id) : [])} /> Select all</label>
      <button disabled={!selected.length} onClick={() => remove(selected)}>Delete selected ({selected.length})</button>
      <button disabled={!items.length} onClick={() => remove(items.map(i => i.id))}>Delete all</button>
    </div>
    <p className="text-xs text-zinc-500">The library is saved in this browser. Deleting a server-rendered export also removes its MP4 from the server. Projects and source footage are kept.</p>
    {error && <p role="alert">{error}</p>}
    <div className="max-h-48 overflow-auto space-y-2">{items.map(item => <div key={item.id} className="flex items-center gap-3">
      <input type="checkbox" aria-label={`Select ${item.title}`} checked={selected.includes(item.id)} onChange={e => setSelected(e.target.checked ? [...selected, item.id] : selected.filter(id => id !== item.id))} />
      <span className="flex-1 truncate">{item.title} · {item.blob ? `${(item.blob.size / 1048576).toFixed(1)} MB` : 'MP4 on server'}</span>
      <button onClick={() => { const url = item.url || (item.blob ? URL.createObjectURL(item.blob) : ''); const a = document.createElement('a'); a.href = url; a.download = `${item.title.replace(/[^a-z0-9_-]/gi, '_')}.${item.url || item.blob?.type.includes('mp4') ? 'mp4' : 'webm'}`; a.click(); if (!item.url) setTimeout(() => URL.revokeObjectURL(url), 1000); }}>Download</button>
      <button onClick={() => remove([item.id])}>Delete</button>
    </div>)}</div>
    {!items.length && <p>No saved exports yet.</p>}
  </section>;
}
