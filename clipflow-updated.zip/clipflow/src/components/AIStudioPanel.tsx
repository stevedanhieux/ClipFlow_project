import React, { useState } from 'react';
import {
  Sparkles,
  Music,
  Sliders,
  Type,
  Copy,
  Check,
  RefreshCw,
  Zap,
  TrendingUp,
  Volume2,
  Film,
  Crop,
  CheckCircle2,
} from 'lucide-react';
import { Project, CaptionStyle, MusicVibe, TargetPlatform } from '../types';
import { generateViralCaptions } from '../services/geminiService';

interface AIStudioPanelProps {
  project: Project;
  onUpdateProject: (updated: Project) => void;
}

export const AIStudioPanel: React.FC<AIStudioPanelProps> = ({ project, onUpdateProject }) => {
  const [activePlatformTab, setActivePlatformTab] = useState<'tiktok' | 'shorts' | 'reels'>('tiktok');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isRegeneratingCaptions, setIsRegeneratingCaptions] = useState(false);
  const [error, setError] = useState('');
  const [nicheInput, setNicheInput] = useState('tech & creator growth');

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(id);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // AI Action 1: Automate Transitions
  const handleAutoTransitions = () => {
    const energyTransitions = ['zoom_in', 'whip_pan', 'glitch', 'flash', 'zoom_out', 'fade'];
    const updatedScenes = project.scenes.map((s, idx) => {
      let t: any = 'zoom_in';
      if (idx === 0) t = 'zoom_in'; // Hook pop
      else if (idx === project.scenes.length - 1) t = 'fade'; // Outro
      else t = energyTransitions[(idx + 1) % energyTransitions.length];
      return { ...s, transition: t };
    });
    onUpdateProject({ ...project, scenes: updatedScenes });
  };

  // AI Action 2: Sync Cuts to Music Beat
  const handleSyncToBeat = () => {
    // 128 BPM has beat duration of ~0.46875s (4 bars = ~1.875s, 8 bars = ~3.75s, 6 bars = ~2.81s)
    let beatUnit = 0.46875;
    if (project.musicVibe === 'phonk') beatUnit = 0.428; // 140 BPM
    if (project.musicVibe === 'lofi') beatUnit = 0.714; // 84 BPM

    const updatedScenes = project.scenes.map((s, idx) => {
      // Snap to nearest 6 or 8 beats
      const targetBeats = idx === 0 ? 6 : (idx % 2 === 0 ? 6 : 8);
      const syncedDuration = Math.round((targetBeats * beatUnit) * 10) / 10;
      return { ...s, duration: Math.max(2.0, syncedDuration) };
    });
    onUpdateProject({ ...project, scenes: updatedScenes });
  };

  // AI Action 3: Smart 9:16 Focal Crop
  const handleSmartCropping = () => {
    const updatedScenes = project.scenes.map((s, idx) => {
      // Auto-compute centered safe zone coords
      const focalY = idx % 2 === 0 ? 0.45 : 0.48; // slightly above optical center for mobile safe zone
      return {
        ...s,
        focalPoint: { x: 0.5, y: focalY },
        zoomScale: 1.15,
      };
    });
    onUpdateProject({ ...project, scenes: updatedScenes });
  };

  // Gemini Viral Captions Regenerator
  const handleRegenerateViralCopy = async () => {
    setError('');
    setIsRegeneratingCaptions(true);
    try {
      const summary = project.scenes.map(s => s.caption).join(' -> ');
      const newCaptions = await generateViralCaptions({
        title: project.title,
        scriptSummary: summary,
        niche: nicheInput,
        targetPlatform: activePlatformTab,
      });

      onUpdateProject({
        ...project,
        viralCaptions: {
          ...project.viralCaptions,
          ...newCaptions,
        },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Caption generation failed.');
    } finally {
      setIsRegeneratingCaptions(false);
    }
  };

  const currentPlatformCopy = project.viralCaptions[activePlatformTab] || {
    hook: 'Wait till you see this...',
    text: 'Check this out!',
    caption: 'Check this out!',
    hashtags: ['#creator', '#viral', '#growth'],
    callToAction: 'Follow for more!',
  };

  const captionStyles: { id: CaptionStyle; name: string; desc: string }[] = [
    { id: 'tiktok_yellow', name: 'TikTok Viral Yellow', desc: 'High-contrast bold font with thick black outline' },
    { id: 'classic_box', name: 'Clean Pill Box', desc: 'Dark frosted background container with white typography' },
    { id: 'karaoke', name: 'Karaoke Highlight', desc: 'Active word highlight with cyan pop' },
    { id: 'minimal_clean', name: 'Minimal Cinema', desc: 'Subtle soft drop-shadow lower-third' },
  ];

  const musicTracks: { id: MusicVibe; name: string; tag: string }[] = [
    { id: 'phonk', name: 'Viral Phonk & Bass', tag: '140 BPM · High Energy' },
    { id: 'lofi', name: 'Lo-Fi Midnight Chill', tag: '84 BPM · Study & Chill' },
    { id: 'pop', name: 'Upbeat Pop Synth', tag: '128 BPM · Tech & Vlog' },
    { id: 'ambient', name: 'Cinematic Ambient', tag: '60 BPM · Storytelling' },
    { id: 'acoustic', name: 'Acoustic Warmth', tag: '110 BPM · Lifestyle' },
    { id: 'none', name: 'Mute Audio', tag: 'Silent Video' },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 pb-10">
      {error && <p role="alert" className="text-rose-500">{error}</p>}
      {/* 1. One-Click AI Automation Engine */}
      <div className="p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Zap className="w-4 h-4 text-rose-500" />
              <span>AI Directing & Auto-Editing</span>
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              One-click algorithms to calibrate transitions, music rhythm, and smart safe-zone framing
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={handleAutoTransitions}
            className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 hover:border-rose-500/50 bg-zinc-50/50 dark:bg-zinc-800/40 text-left transition-all hover:shadow-sm cursor-pointer group min-h-[56px]"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                Automate Transitions
              </span>
              <Film className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              Intelligently assigns zoom-ins, whip pans, and glitch cuts based on scene energy.
            </p>
          </button>

          <button
            type="button"
            onClick={handleSyncToBeat}
            className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 hover:border-rose-500/50 bg-zinc-50/50 dark:bg-zinc-800/40 text-left transition-all hover:shadow-sm cursor-pointer group min-h-[56px]"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                Sync Cuts to Beat
              </span>
              <Music className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              Snaps scene durations to musical measure downbeats for punchy flow.
            </p>
          </button>

          <button
            type="button"
            onClick={handleSmartCropping}
            className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 hover:border-rose-500/50 bg-zinc-50/50 dark:bg-zinc-800/40 text-left transition-all hover:shadow-sm cursor-pointer group min-h-[56px]"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                Smart 9:16 Focal Crop
              </span>
              <Crop className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              Auto-centers focal subjects above the TikTok / Shorts caption danger zone.
            </p>
          </button>
        </div>
      </div>

      {/* 2. Background Music & Sound Suite */}
      <div className="p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Music className="w-4 h-4 text-rose-500" />
              <span>Background Music & Beats</span>
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Royalty-free procedural sound tracks rendered in real-time and embedded in exported videos
            </p>
          </div>
        </div>

        {/* Music Track Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {musicTracks.map(m => {
            const isActive = project.musicVibe === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => onUpdateProject({ ...project, musicVibe: m.id })}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer min-h-[54px] ${
                  isActive
                    ? 'border-rose-600 bg-rose-50/60 dark:bg-rose-950/40 text-rose-900 dark:text-rose-100 shadow-sm'
                    : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/30 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">{m.name}</span>
                  {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                </div>
                <div className="text-[10px] opacity-75 mt-0.5">{m.tag}</div>
              </button>
            );
          })}
        </div>

        {/* Music Volume Slider */}
        {project.musicVibe !== 'none' && (
          <div className="pt-2 flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-zinc-700 dark:text-zinc-300 shrink-0">
              <Volume2 className="w-4 h-4 text-zinc-500" />
              <span>Music Level: {project.musicVolume}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={project.musicVolume}
              onChange={e => onUpdateProject({ ...project, musicVolume: parseInt(e.target.value) })}
              className="flex-1 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>
        )}
      </div>

      {/* 3. Caption Typography Styling */}
      <div className="p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-4">
        <div className="space-y-0.5">
          <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
            <Type className="w-4 h-4 text-rose-500" />
            <span>On-Screen Caption Styling</span>
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Presets crafted for maximum legibility on mobile screens
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {captionStyles.map(cs => {
            const isActive = project.captionStyle === cs.id;
            return (
              <button
                key={cs.id}
                type="button"
                onClick={() => onUpdateProject({ ...project, captionStyle: cs.id })}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer min-h-[56px] ${
                  isActive
                    ? 'border-rose-600 bg-rose-50/60 dark:bg-rose-950/40 text-rose-900 dark:text-rose-100 shadow-sm'
                    : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/30 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold">{cs.name}</span>
                  {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                </div>
                <p className="text-[11px] opacity-75 mt-1">{cs.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Gemini Viral Copy & Trending Hashtags Suite */}
      <div className="p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-rose-500" />
              <span>Gemini Viral Copy & Trending Hashtags</span>
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              High-CTR hooks and SEO hashtags tailored for social algorithm discovery
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={nicheInput}
              onChange={e => setNicheInput(e.target.value)}
              placeholder="e.g. fitness, tech, food"
              className="px-3 py-1.5 text-xs rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400"
            />
            <button
              onClick={handleRegenerateViralCopy}
              disabled={isRegeneratingCaptions}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer min-h-[40px] whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRegeneratingCaptions ? 'animate-spin' : ''}`} />
              <span>Refresh Copy</span>
            </button>
          </div>
        </div>

        {/* Platform Tabs */}
        <div className="flex items-center gap-1 p-1 bg-zinc-100 dark:bg-zinc-800 rounded-xl w-fit">
          {[
            { id: 'tiktok', label: 'TikTok Copy' },
            { id: 'shorts', label: 'YouTube Shorts' },
            { id: 'reels', label: 'Instagram Reels' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActivePlatformTab(tab.id as any)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer min-h-[36px] ${
                activePlatformTab === tab.id
                  ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Box */}
        <div className="p-4 sm:p-5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 space-y-4">
          {/* Hook */}
          {currentPlatformCopy.hook && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                  Viral Hook (First 2 Seconds)
                </span>
                <button
                  onClick={() => copyToClipboard(currentPlatformCopy.hook || '', 'hook')}
                  className="flex items-center gap-1 text-[11px] text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer"
                >
                  {copiedField === 'hook' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedField === 'hook' ? 'Copied' : 'Copy Hook'}</span>
                </button>
              </div>
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400 p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                "{currentPlatformCopy.hook}"
              </p>
            </div>
          )}

          {/* Body Caption */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Description & Caption</span>
              <button
                onClick={() =>
                  copyToClipboard(
                    `${currentPlatformCopy.text || currentPlatformCopy.caption || ''}\n\n${(
                      currentPlatformCopy.hashtags || []
                    ).join(' ')}`,
                    'full_caption'
                  )
                }
                className="flex items-center gap-1 text-[11px] text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer"
              >
                {copiedField === 'full_caption' ? (
                  <Check className="w-3 h-3 text-emerald-500" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
                <span>{copiedField === 'full_caption' ? 'Copied Full Post' : 'Copy Post & Tags'}</span>
              </button>
            </div>
            <p className="text-xs text-zinc-800 dark:text-zinc-200 p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 leading-relaxed whitespace-pre-line">
              {currentPlatformCopy.text || currentPlatformCopy.caption || 'No caption generated'}
            </p>
          </div>

          {/* Hashtags */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Trending Hashtags</span>
              <button
                onClick={() =>
                  copyToClipboard((currentPlatformCopy.hashtags || []).join(' '), 'hashtags')
                }
                className="flex items-center gap-1 text-[11px] text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer"
              >
                {copiedField === 'hashtags' ? (
                  <Check className="w-3 h-3 text-emerald-500" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
                <span>{copiedField === 'hashtags' ? 'Copied' : 'Copy All Tags'}</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(currentPlatformCopy.hashtags || []).map((tag, idx) => (
                <span
                  key={idx}
                  onClick={() => copyToClipboard(tag, `tag-${idx}`)}
                  className="px-2.5 py-1 rounded-lg text-xs font-mono-nums bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-rose-400 cursor-pointer transition-colors"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
