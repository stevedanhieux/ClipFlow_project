import React, { useRef } from 'react';
import { X, Sparkles, Sliders, Image as ImageIcon, Check } from 'lucide-react';
import { Scene, TransitionType } from '../types';

interface SceneInspectorProps {
  scene: Scene | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveScene: (updatedScene: Scene) => void;
}

export const SceneInspector: React.FC<SceneInspectorProps> = ({
  scene,
  isOpen,
  onClose,
  onSaveScene,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen || !scene) return null;

  const handleUpdate = (fields: Partial<Scene>) => {
    onSaveScene({ ...scene, ...fields });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = ev => {
        handleUpdate({
          mediaUrl: ev.target?.result as string,
          mediaType: 'image',
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFocalPointClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    handleUpdate({ focalPoint: { x, y } });
  };

  const transitions: { id: TransitionType; name: string }[] = [
    { id: 'zoom_in', name: 'Zoom In' },
    { id: 'zoom_out', name: 'Zoom Out' },
    { id: 'glitch', name: 'Glitch' },
    { id: 'whip_pan', name: 'Whip Pan' },
    { id: 'flash', name: 'Flash' },
    { id: 'slide_left', name: 'Slide' },
    { id: 'fade', name: 'Fade' },
  ];

  const presetColors = ['#f43f5e', '#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ec4899', '#06b6d4'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-lg text-zinc-900 dark:text-zinc-100">
              Edit Scene 0{scene.sceneNumber}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Caption Text (On-screen overlay) */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              On-Screen Caption (Punchy text overlay)
            </label>
            <input
              type="text"
              value={scene.caption}
              onChange={e => handleUpdate({ caption: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/60 text-zinc-900 dark:text-zinc-100 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-rose-500"
              placeholder="e.g. STOP SCROLLING 🚨"
            />
          </div>

          {/* Voiceover Narration Script */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              Voiceover Script / Narration
            </label>
            <textarea
              rows={2}
              value={scene.voiceover}
              onChange={e => handleUpdate({ voiceover: e.target.value })}
              className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/60 text-zinc-900 dark:text-zinc-100 text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-500"
              placeholder="Spoken words for this scene..."
            />
          </div>

          {/* Scene Duration Slider */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Duration</span>
              <span className="font-mono-nums text-rose-600 font-bold">{scene.duration.toFixed(1)} seconds</span>
            </div>
            <input
              type="number"
              min={0.1}
              max={scene.mediaType === 'video' ? (scene.sourceDuration || 7200) - (scene.trimStart || 0) : undefined}
              step={0.1}
              value={scene.duration}
              onChange={e => { const duration = Number(e.target.value); if (Number.isFinite(duration) && duration >= .1 && (scene.mediaType !== 'video' || duration + (scene.trimStart || 0) <= (scene.sourceDuration || Infinity))) handleUpdate({ duration }); }}
              className="w-full h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>

          {/* Transition Type */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Transition Effect</span>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
              {transitions.map(t => {
                const isActive = scene.transition === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => handleUpdate({ transition: t.id })}
                    className={`py-2 px-1 text-[11px] font-medium rounded-lg border text-center transition-all cursor-pointer min-h-[44px] ${
                      isActive
                        ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold'
                        : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:border-zinc-300'
                    }`}
                  >
                    {t.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interactive Smart Focal Point & Ken Burns Motion */}
          <div className="space-y-2 pt-1 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                Smart Focal Crop & Auto-Pan
              </span>
              <span className="text-[11px] text-zinc-400">Tap preview to place focal center</span>
            </div>

            <div
              onClick={handleFocalPointClick}
              className="relative w-full h-36 rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-700 cursor-crosshair group flex items-center justify-center"
              style={{
                background: scene.mediaUrl
                  ? `url(${scene.mediaUrl}) center/cover no-repeat`
                  : scene.accentColor || '#f43f5e',
              }}
            >
              {/* Target Dot */}
              <div
                className="absolute w-6 h-6 rounded-full border-2 border-white bg-rose-600/80 shadow-lg -translate-x-1/2 -translate-y-1/2 pointer-events-none flex items-center justify-center text-[10px] text-white font-bold"
                style={{
                  left: `${(scene.focalPoint?.x ?? 0.5) * 100}%`,
                  top: `${(scene.focalPoint?.y ?? 0.5) * 100}%`,
                }}
              >
                +
              </div>

              {/* Instructions banner */}
              <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/60 text-[10px] text-white/90">
                Focal: {((scene.focalPoint?.x ?? 0.5) * 100).toFixed(0)}%,{' '}
                {((scene.focalPoint?.y ?? 0.5) * 100).toFixed(0)}%
              </div>
            </div>

            {/* Ken Burns Zoom Scale Slider */}
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-zinc-600 dark:text-zinc-400">Motion Zoom Scale:</span>
              <span className="font-mono-nums font-bold text-zinc-800 dark:text-zinc-200">
                {((scene.zoomScale ?? 1.15) * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="number"
              min={0.1}
              max={1.35}
              step={0.02}
              value={scene.zoomScale ?? 1.15}
              onChange={e => handleUpdate({ zoomScale: parseFloat(e.target.value) })}
              className="w-full h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>

          {/* Media / Image Replacement */}
          <div className="space-y-2 pt-1 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Scene Background Asset</span>
              {scene.mediaUrl && (
                <button
                  type="button"
                  onClick={() => handleUpdate({ mediaUrl: undefined, mediaType: 'color' })}
                  className="text-rose-600 text-xs hover:underline cursor-pointer"
                >
                  Use Color Preset
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors cursor-pointer min-h-[44px]"
              >
                <ImageIcon className="w-4 h-4 text-zinc-500" />
                <span>Upload Scene Photo</span>
              </button>

              {/* Accent Color picker */}
              <div className="flex items-center gap-1.5">
                {presetColors.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => handleUpdate({ accentColor: c })}
                    style={{ backgroundColor: c }}
                    className={`w-6 h-6 rounded-full border transition-transform cursor-pointer ${
                      scene.accentColor === c ? 'scale-125 ring-2 ring-zinc-400' : 'hover:scale-110'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-zinc-100 dark:border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs sm:text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors shadow-sm cursor-pointer min-h-[44px]"
          >
            Done Editing
          </button>
        </div>
      </div>
    </div>
  );
};
