import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Eye,
  EyeOff,
  Maximize2,
  Sparkles,
  Layers,
  Music,
} from 'lucide-react';
import { Project, Scene, CaptionStyle, TargetPlatform } from '../types';
import { drawFrameAtTime } from '../services/videoExporter';
import { audioEngine } from '../services/audioEngine';

interface VideoPreviewCanvasProps {
  project: Project;
  currentTime: number;
  setCurrentTime: React.Dispatch<React.SetStateAction<number>>;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  onEditScene: (scene: Scene) => void;
}

export const VideoPreviewCanvas: React.FC<VideoPreviewCanvasProps> = ({
  project,
  currentTime,
  setCurrentTime,
  isPlaying,
  setIsPlaying,
  onEditScene,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showSafeZones, setShowSafeZones] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [loadedImages, setLoadedImages] = useState<{ [sceneId: string]: HTMLImageElement }>({});

  const totalDuration = project.scenes.reduce((acc, s) => acc + s.duration, 0) || 1;

  // Preload project images whenever scenes change
  useEffect(() => {
    let isCancelled = false;
    const cache: { [id: string]: HTMLImageElement } = {};

    project.scenes.forEach(scene => {
      if (scene.mediaUrl) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          if (!isCancelled) {
            cache[scene.id] = img;
            setLoadedImages(prev => ({ ...prev, [scene.id]: img }));
          }
        };
        img.src = scene.mediaUrl;
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [project.scenes]);

  useEffect(() => () => audioEngine.stopPlayback(), []);

  // Audio engine sync
  useEffect(() => {
    audioEngine.setMusicVibe(project.musicVibe, project.customMusicUrl);
    audioEngine.setVolume(isMuted ? 0 : project.musicVolume);
  }, [project.musicVibe, project.customMusicUrl, project.musicVolume, isMuted]);

  // Playback timer & requestAnimationFrame loop
  useEffect(() => {
    let animId: number;
    let lastTimestamp = performance.now();

    const loop = (now: number) => {
      const deltaSec = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      if (isPlaying) {
        setCurrentTime((prevTime: number) => {
          let nextTime = prevTime + deltaSec;
          if (nextTime >= totalDuration) {
            nextTime = 0; // Loop seamlessly
            audioEngine.startPlayback(0);
          }
          return nextTime;
        });
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);

    return () => cancelAnimationFrame(animId);
  }, [isPlaying, totalDuration, setCurrentTime]);

  // Render canvas frame when currentTime or project updates
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawFrameAtTime(ctx, canvas.width, canvas.height, project, currentTime, loadedImages);
  }, [project, currentTime, loadedImages]);

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      audioEngine.stopPlayback();
      setIsPlaying(false);
    } else {
      audioEngine.startPlayback(currentTime);
      setIsPlaying(true);
    }
  }, [isPlaying, currentTime, setIsPlaying]);

  const handleRestart = useCallback(() => {
    setCurrentTime(0);
    audioEngine.seek(0);
    if (!isPlaying) {
      audioEngine.startPlayback(0);
      setIsPlaying(true);
    }
  }, [setCurrentTime, isPlaying, setIsPlaying]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    audioEngine.seek(val);
  };

  // Determine active scene
  let accumulated = 0;
  let activeSceneIndex = 0;
  for (let i = 0; i < project.scenes.length; i++) {
    if (currentTime >= accumulated && currentTime < accumulated + project.scenes[i].duration) {
      activeSceneIndex = i;
      break;
    }
    accumulated += project.scenes[i].duration;
  }
  const activeScene = project.scenes[activeSceneIndex] || project.scenes[0];

  // Aspect ratio geometry classes
  const aspectClass =
    project.aspectRatio === '1:1'
      ? 'aspect-square max-w-[420px]'
      : project.aspectRatio === '16:9'
      ? 'aspect-video max-w-[640px]'
      : 'aspect-[9/16] max-w-[340px] sm:max-w-[360px]';

  return (
    <div className="w-full flex flex-col items-center space-y-4">
      {/* Player Canvas Wrapper with Mobile Screen Mock & Safe-zone Guide */}
      <div
        ref={containerRef}
        className={`relative w-full ${aspectClass} mx-auto rounded-3xl overflow-hidden shadow-2xl bg-zinc-950 border-4 border-zinc-800/80 select-none group`}
      >
        <canvas
          ref={canvasRef}
          width={project.aspectRatio === '1:1' ? 1080 : project.aspectRatio === '16:9' ? 1920 : 1080}
          height={project.aspectRatio === '1:1' ? 1080 : project.aspectRatio === '16:9' ? 1080 : 1920}
          className="w-full h-full object-contain cursor-pointer"
          onClick={togglePlay}
        />

        {/* Social Media Safe Zone Overlay (TikTok / Reels / Shorts UI simulation) */}
        {showSafeZones && project.aspectRatio === '9:16' && (
          <div
            className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-4"
            aria-hidden="true"
          >
            {/* Top Navigation Simulation (Following | For You / Sound) */}
            <div className="flex items-center justify-between text-[11px] text-white/50 font-medium px-2 pt-2">
              <div className="w-12 h-0.5 bg-white/20 rounded" />
              <div className="flex items-center gap-3">
                <span className="opacity-40">Following</span>
                <span className="text-white/80 font-bold border-b border-white">For You</span>
              </div>
              <div className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center text-[9px]">
                🔍
              </div>
            </div>

            {/* Right Side Interaction Bar (Likes, Comments, Bookmarks, Share, Audio Disc) */}
            <div className="absolute right-3 bottom-20 flex flex-col items-center gap-3.5 text-white/70">
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-xs">
                  ❤️
                </div>
                <span className="text-[9px] font-mono-nums mt-0.5">84.2K</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-xs">
                  💬
                </div>
                <span className="text-[9px] font-mono-nums mt-0.5">1.2K</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-xs">
                  🔖
                </div>
                <span className="text-[9px] font-mono-nums mt-0.5">9.8K</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-xs">
                  ↗️
                </div>
                <span className="text-[9px] font-mono-nums mt-0.5">Share</span>
              </div>
              <div className="w-7 h-7 rounded-full bg-zinc-800 border-2 border-zinc-700 flex items-center justify-center text-[10px] animate-spin">
                💿
              </div>
            </div>

            {/* Bottom Caption & Handle Safe Zone */}
            <div className="pl-2 pr-14 pb-2 space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white/90">@creator</span>
                <span className="text-[10px] text-white/60">· 2h ago</span>
              </div>
              <p className="text-[11px] text-white/70 line-clamp-1">
                {project.viralCaptions.tiktok?.text || 'Automated with ClipFlow AI'}
              </p>
              <div className="flex items-center gap-1 text-[10px] text-white/50">
                <Music className="w-3 h-3 animate-pulse" />
                <span className="truncate max-w-[140px]">{project.musicVibe.toUpperCase()} BEATS</span>
              </div>
            </div>

            {/* Safe Zone Boundary Marker Lines */}
            <div className="absolute inset-x-4 top-14 bottom-32 border border-dashed border-rose-500/30 rounded-xl pointer-events-none">
              <span className="absolute top-1 left-2 text-[9px] font-mono-nums text-rose-400/60 uppercase">
                Safe Zone (Captions & Focal Subject)
              </span>
            </div>
          </div>
        )}

        {/* Quick Edit Current Scene Floating Pill */}
        {activeScene && (
          <button
            onClick={() => onEditScene(activeScene)}
            className="absolute top-3 left-3 z-20 px-2.5 py-1 rounded-lg bg-zinc-900/80 backdrop-blur-md border border-zinc-700 text-white text-[11px] font-medium flex items-center gap-1.5 hover:bg-zinc-800 transition-colors shadow-sm cursor-pointer"
          >
            <span>Scene {activeScene.sceneNumber}</span>
            <span className="opacity-50">·</span>
            <span className="text-rose-400 capitalize">{activeScene.transition.replace('_', ' ')}</span>
          </button>
        )}

        {/* Play/Pause Overlay Hitbox */}
        <div
          onClick={togglePlay}
          className={`absolute inset-0 z-10 flex items-center justify-center transition-opacity cursor-pointer ${
            isPlaying ? 'opacity-0 hover:opacity-100 bg-black/20' : 'opacity-100 bg-black/40'
          }`}
        >
          <div className="w-14 h-14 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-lg transform active:scale-95 transition-transform">
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
          </div>
        </div>
      </div>

      {/* Playback Controls & Time Scrubber */}
      <div className="w-full max-w-xl px-2 space-y-2">
        {/* Scrubber Bar */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 w-12 text-right shrink-0">
            {formatTime(currentTime)}
          </span>

          <div className="relative flex-1 flex items-center">
            <input
              type="range"
              min={0}
              max={totalDuration}
              step={0.05}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>

          <span className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 w-12 shrink-0">
            {formatTime(totalDuration)}
          </span>
        </div>

        {/* Button Controls Row */}
        <div className="flex items-center justify-between gap-2">
          {/* Left: Playback Triggers */}
          <div className="flex items-center gap-1">
            <button
              onClick={handleRestart}
              title="Restart from beginning"
              className="p-2 rounded-lg text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={togglePlay}
              className="px-3.5 py-1.5 rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 font-semibold text-xs flex items-center gap-1.5 hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-colors min-h-[44px] cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
              <span>{isPlaying ? 'Pause' : 'Play'}</span>
            </button>
          </div>

          {/* Right: Safe Zone & Audio Mute Toggles */}
          <div className="flex items-center gap-1">
            {/* Safe Zone Toggle */}
            <button
              onClick={() => setShowSafeZones(!showSafeZones)}
              title={showSafeZones ? 'Hide social UI safe zone guide' : 'Show social UI safe zone guide'}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors min-h-[44px] cursor-pointer ${
                showSafeZones
                  ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
            >
              {showSafeZones ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">Safe Zone</span>
            </button>

            {/* Mute Toggle */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              title={isMuted ? 'Unmute music' : 'Mute music'}
              className="p-2 rounded-lg text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  const ds = Math.floor((sec % 1) * 10);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ds}`;
}
