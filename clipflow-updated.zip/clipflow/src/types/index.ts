export type TargetPlatform = 'tiktok' | 'shorts' | 'reels' | 'cross_platform';

export type AspectRatio = '9:16' | '1:1' | '16:9';

export type TransitionType =
  | 'fade'
  | 'zoom_in'
  | 'zoom_out'
  | 'glitch'
  | 'whip_pan'
  | 'flash'
  | 'slide_left';

export type CaptionStyle =
  | 'tiktok_yellow'
  | 'classic_box'
  | 'karaoke'
  | 'minimal_clean';

export type MusicVibe =
  | 'phonk'
  | 'lofi'
  | 'pop'
  | 'ambient'
  | 'acoustic'
  | 'custom'
  | 'none';

export interface Scene {
  id: string;
  sceneNumber: number;
  caption: string;
  voiceover: string;
  duration: number; // in seconds
  transition: TransitionType;
  visualDirection: string;
  mediaUrl?: string; // image data URL or background image
  mediaType: 'image' | 'color' | 'video';
  trimStart?: number;
  sourceDuration?: number;
  sourceVolume?: number;
  accentColor: string;
  focalPoint: { x: number; y: number }; // 0 to 1
  zoomScale: number; // 1.0 to 1.3
}

export interface PlatformCaption {
  text?: string;
  hook?: string;
  caption?: string;
  callToAction?: string;
  hashtags: string[];
}

export interface Project {
  id: string;
  title: string;
  targetPlatform: TargetPlatform;
  aspectRatio: AspectRatio;
  captionStyle: CaptionStyle;
  musicVibe: MusicVibe;
  musicVolume: number; // 0 to 100
  customMusicUrl?: string;
  scenes: Scene[];
  viralCaptions: {
    tiktok: PlatformCaption;
    shorts: PlatformCaption;
    reels: PlatformCaption;
  };
  viralScore?: number;
  createdAt: number;
  updatedAt: number;
}
