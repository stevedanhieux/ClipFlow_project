import React, { useRef, useState } from 'react';
import { Project, Scene } from '../types';
import { saveExportReference } from '../services/exportLibrary';
import { ExportLibrary } from './ExportLibrary';

async function api(url: string, body: any) {
  const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Request failed'); return data;
}
export function DirectorWorkspace({ project, onUpdate }: { project: Project; onUpdate: (p: Project) => void }) {
  const [tab, setTab] = useState<'files' | 'social'>('files');
  const [provider, setProvider] = useState('gemini'); const [model, setModel] = useState('');
  const [command, setCommand] = useState(''); const [social, setSocial] = useState('');
  const [message, setMessage] = useState(''); const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Project | null>(null); const [selected, setSelected] = useState<string[]>([]);
  const [history, setHistory] = useState<Project[]>([]); const [future, setFuture] = useState<Project[]>([]);
  const [preferences, setPreferences] = useState(() => localStorage.getItem('clipflow_preferences') || '');
  const [remember, setRemember] = useState(false); const [refresh, setRefresh] = useState(0);
  const [playIndex, setPlayIndex] = useState(0); const video = useRef<HTMLVideoElement>(null);
  const [renderedUrl, setRenderedUrl] = useState('');
  const shown = draft || project; const scene = shown.scenes[playIndex];
  const commit = (next: Project) => { setHistory(h => [...h.slice(-29), project]); setFuture([]); onUpdate(next); setDraft(null); setPlayIndex(0); setSelected([]); };
  const operation = async (work: () => Promise<void>) => { setBusy(true); setMessage('Working…'); try { await work(); } catch (e: any) { setMessage(e.message); } finally { setBusy(false); } };
  const loadMedia = async (url: string, title: string, image = false): Promise<Scene> => {
    let duration = 5;
    if (!image) duration = await new Promise<number>((resolve, reject) => {
      const el = document.createElement('video'); el.preload = 'metadata'; el.src = url;
      const timer = setTimeout(() => { el.src = ''; reject(new Error('Video metadata timed out.')); }, 20000);
      el.onloadedmetadata = () => { clearTimeout(timer); if (!Number.isFinite(el.duration) || el.duration <= 0) reject(new Error('Video duration is unavailable.')); else resolve(el.duration); el.removeAttribute('src'); el.load(); };
      el.onerror = () => { clearTimeout(timer); reject(new Error('This browser cannot preview this video. Try MP4 (H.264).')); };
    });
    return { id: crypto.randomUUID(), sceneNumber: 1, caption: '', voiceover: '', duration, sourceDuration: duration, trimStart: 0, sourceVolume: 1, mediaUrl: url, mediaType: image ? 'image' : 'video', visualDirection: title, accentColor: '#f43f5e', focalPoint: {x:0.5,y:0.5}, zoomScale: 1, transition: 'fade' };
  };
  const importFiles = (files: File[]) => operation(async () => {
    const additions: Scene[] = [];
    for (const file of files) {
      if (!file.type.startsWith('video/') && !file.type.startsWith('image/')) throw new Error('Drop video or image files here.');
      const response = await fetch('/api/studio/upload', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.name) }, body: file });
      const data = await response.json(); if (!response.ok) throw new Error(data.error);
      additions.push(await loadMedia(data.url, file.name, file.type.startsWith('image/')));
    }
    const existing = project.scenes.filter(s => s.mediaUrl);
    commit({ ...project, musicVibe: 'none', scenes: [...existing,...additions].map((s,i) => ({...s,sceneNumber:i+1})) }); setMessage('Imported. Describe your edit or use the timeline below.');
  });
  const editScene = (id: string, changes: Partial<Scene>) => commit({ ...project, scenes: project.scenes.map(s => s.id === id ? {...s,...changes} : s) });
  const split = () => {
    if (!scene || draft) return;
    const offset = scene.mediaType === 'video' ? (video.current?.currentTime ?? 0) - (scene.trimStart || 0) : scene.duration / 2;
    if (offset < .1 || offset > scene.duration - .1) { setMessage('Move the playhead inside the clip before splitting.'); return; }
    const scenes = project.scenes.flatMap(s => s.id !== scene.id ? [s] : [{...s,duration:offset},{...s,id:crypto.randomUUID(),trimStart:(s.trimStart || 0)+offset,duration:s.duration-offset}]);
    commit({...project,scenes:scenes.map((s,i) => ({...s,sceneNumber:i+1}))});
  };
  const render = (preview = false) => operation(async () => {
    if (draft && !preview) throw new Error('Accept your draft before exporting.');
    const renderProject = preview ? shown : project;
    const {id} = await api('/api/studio/render',{project:renderProject});
    while (true) {
      await new Promise(resolve => setTimeout(resolve,2000));
      const response = await fetch(`/api/studio/render/${id}`); const result = await response.json();
      if (!response.ok || result.status === 'failed') throw new Error(result.error);
      if (result.status === 'complete') {
        setRenderedUrl(result.url);
        try { await saveExportReference(`${preview ? 'Preview — ' : ''}${renderProject.title}`, result.url); setRefresh(r => r+1); setMessage(preview ? 'Rendered draft ready to review below.' : 'MP4 saved in your export library.'); }
        catch { setMessage('MP4 rendered, but browser storage is full. Download from the video below.'); }
        break;
      }
      setMessage('Rendering MP4 to disk. You can keep using other tabs.');
    }
  });
  const button = 'px-3 py-2 rounded-lg bg-zinc-200 dark:bg-zinc-800 disabled:opacity-40';
  return <div className="space-y-5 max-w-5xl mx-auto">
    <div><h2 className="text-xl font-bold">Video editor & AI director</h2><p className="text-sm text-zinc-500">1. Import footage · 2. Describe or edit · 3. Preview and export</p></div>
    <section className="p-5 rounded-2xl bg-white dark:bg-zinc-900 space-y-4">
      <div className="flex gap-2"><button className={button} onClick={() => setTab('files')}>Files / drag & drop</button><button className={button} onClick={() => setTab('social')}>Social import</button></div>
      {tab === 'files' ? <label className="block p-8 border-2 border-dashed rounded-xl text-center cursor-pointer" onDragOver={e => e.preventDefault()} onDrop={e => {e.preventDefault(); if (!busy) importFiles(Array.from(e.dataTransfer.files));}}>Drop videos or images here, or choose files<input className="block mx-auto mt-3" type="file" accept="video/*,image/*" multiple disabled={busy} onChange={e => { if (e.target.files) importFiles(Array.from(e.target.files)); e.target.value = ''; }} /></label> : <div className="space-y-2"><input className="w-full p-3 bg-transparent border rounded" aria-label="Social video URL" placeholder="Paste a public YouTube, Vimeo, TikTok, Instagram or Facebook link" value={social} onChange={e => setSocial(e.target.value)} /><button className={button} disabled={busy} onClick={() => operation(async () => { const data = await api('/api/studio/social',{url:social}); const addition = await loadMedia(data.url,'Social import'); commit({...project,musicVibe:'none',scenes:[...project.scenes.filter(s => s.mediaUrl),addition].map((s,i) => ({...s,sceneNumber:i+1}))}); setMessage('Social video imported.'); })}>Import video</button><p className="text-xs text-zinc-500">Requires yt-dlp and FFmpeg on the server. Import videos you have permission to use. Login-only or blocked videos may require downloading through the platform first.</p></div>}
      <div className="flex gap-3 flex-wrap"><label>AI provider <select className="bg-zinc-100 dark:bg-zinc-800 p-2 rounded" value={provider} onChange={e => {setProvider(e.target.value);setModel('');}}><option value="ollama">Ollama — local, no API fee</option><option value="gemini">Gemini — limited free tier</option><option value="openai">OpenAI / ChatGPT — paid API</option><option value="claude">Claude — paid API</option><option value="compatible">Other compatible provider</option></select></label><input className="p-2 bg-transparent border rounded" aria-label="AI model override" placeholder="Model (optional override)" value={model} onChange={e => setModel(e.target.value)} /></div>
      <textarea className="w-full p-3 bg-transparent border rounded" aria-label="Editing command" placeholder="Example: Make a 30-second highlight, add concise captions, and use landscape framing." value={command} onChange={e => setCommand(e.target.value)} />
      <div className="flex gap-3 items-center flex-wrap"><button className={button} disabled={busy || !command.trim()} onClick={() => operation(async () => { const next = await api('/api/studio/direct',{ provider,model,command,project:shown,preferences }); setDraft(next); setPlayIndex(0); setMessage('Draft ready. Preview, accept, or describe another revision.'); })}>{draft ? 'Revise draft' : 'Create AI draft'}</button><label><input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} /> Remember accepted instructions</label></div>
      <p className="text-xs text-zinc-500">AI edits timeline metadata and captions from your brief. It does not inspect video frames, transcribe speech, or generate new footage. Preference memory stores accepted instructions locally; it does not retrain the model.</p>
      {preferences && <button className={button} onClick={() => {localStorage.removeItem('clipflow_preferences');setPreferences('');}}>Clear preference memory</button>}
      {draft && <div className="flex gap-3"><button className={button} disabled={busy} onClick={() => render(true)}>Render draft preview</button><button className={button} disabled={busy} onClick={() => {commit(draft); if (remember) { const next = `${preferences}\n${command}`.slice(-4000);setPreferences(next);localStorage.setItem('clipflow_preferences',next); } setMessage('Draft accepted.');}}>Accept draft</button><button className={button} disabled={busy} onClick={() => {setDraft(null);setPlayIndex(0);}}>Discard draft</button></div>}
      <p role="status" className="text-sm text-rose-500 whitespace-pre-wrap">{message}</p>
    </section>
    <section className="p-5 bg-white dark:bg-zinc-900 rounded-2xl space-y-3">
      <div className="flex flex-wrap gap-3"><input aria-label="Project title" className="p-2 border rounded bg-transparent" disabled={!!draft} value={project.title} onChange={e => onUpdate({...project,title:e.target.value})}/><select aria-label="Aspect ratio" className="p-2 bg-zinc-100 dark:bg-zinc-800" disabled={!!draft} value={shown.aspectRatio} onChange={e => commit({...project,aspectRatio:e.target.value as Project['aspectRatio']})}><option>16:9</option><option>9:16</option><option>1:1</option></select><span>{(shown.scenes.reduce((a,s) => a+s.duration,0)/60).toFixed(2)} minutes · no 60-minute cap</span></div>
      {scene?.mediaType === 'video' ? <video key={`${scene.id}-${scene.mediaUrl}`} ref={video} className="w-full max-h-96 bg-black" src={scene.mediaUrl} controls onLoadedMetadata={e => {e.currentTarget.currentTime=scene.trimStart || 0; e.currentTarget.volume=scene.sourceVolume ?? 1;}} onTimeUpdate={e => {if (e.currentTarget.currentTime >= (scene.trimStart || 0)+scene.duration) {e.currentTarget.pause();e.currentTarget.currentTime=scene.trimStart || 0;}}} /> : scene?.mediaUrl ? <img className="max-h-80 mx-auto" src={scene.mediaUrl} alt={scene.visualDirection} /> : <p>Import footage to preview it here. Generated slide projects use the Studio preview.</p>}
      {scene?.caption && <p className="text-center font-bold">{scene.caption}</p>}
      <p className="text-xs text-zinc-500">Source clip preview. Final MP4 uses fitted framing and simple caption overlays. Clips play individually here. FFmpeg export preserves source audio; slide effects and generated music use Studio export.</p>
      <div className="flex flex-wrap gap-2"><button className={button} disabled={!history.length || !!draft} onClick={() => {const prev=history[history.length-1];setHistory(history.slice(0,-1));setFuture([...future,project]);onUpdate(prev);setPlayIndex(0);}}>Undo</button><button className={button} disabled={!future.length || !!draft} onClick={() => {const next=future[future.length-1];setFuture(future.slice(0,-1));setHistory([...history,project]);onUpdate(next);setPlayIndex(0);}}>Redo</button><button className={button} disabled={!!draft} onClick={split}>Split at playhead</button><button className={button} disabled={!selected.length || !!draft} onClick={() => {if (window.confirm(`Remove ${selected.length} clip(s) from the timeline?`)) commit({...project,scenes:project.scenes.filter(s => !selected.includes(s.id)).map((s,i)=>({...s,sceneNumber:i+1}))});}}>Delete selected clips</button></div>
      <label><input type="checkbox" checked={shown.scenes.length>0 && selected.length===shown.scenes.length} onChange={e => setSelected(e.target.checked ? shown.scenes.map(s=>s.id) : [])} /> Select all clips</label>
      <div className="space-y-3 max-h-96 overflow-auto">{shown.scenes.map((s,i) => <div key={s.id} className={`p-3 border rounded-xl space-y-2 ${i===playIndex?'border-rose-500':''}`} draggable={!draft} onDragStart={e => e.dataTransfer.setData('text/plain',s.id)} onDragOver={e=>e.preventDefault()} onDrop={e => { e.preventDefault();if(draft)return;const id=e.dataTransfer.getData('text/plain');const moving=project.scenes.find(s=>s.id===id);if(!moving)return;const next=project.scenes.filter(s=>s.id!==id);next.splice(i,0,moving);commit({...project,scenes:next.map((s,i)=>({...s,sceneNumber:i+1}))}); }}>
        <div className="flex gap-3"><input type="checkbox" aria-label={`Select clip ${i+1}`} checked={selected.includes(s.id)} onChange={e=>setSelected(e.target.checked?[...selected,s.id]:selected.filter(id=>id!==s.id))}/><button onClick={()=>setPlayIndex(i)}>Clip {i+1}: {s.visualDirection || s.caption || 'Untitled'} · {s.duration.toFixed(1)}s</button></div>
        <div className="flex gap-3 flex-wrap"><label>Start (s) <input type="number" className="w-24 bg-transparent border rounded p-1" min="0" step="0.1" disabled={!!draft || s.mediaType!=='video'} value={s.trimStart||0} onChange={e=>{const value=Number(e.target.value);if(value>=0&&value+s.duration<=(s.sourceDuration||Infinity))editScene(s.id,{trimStart:value});}}/></label><label>Duration (s) <input type="number" className="w-24 bg-transparent border rounded p-1" min="0.1" step="0.1" disabled={!!draft} value={s.duration} onChange={e=>{const value=Number(e.target.value);if(value>=.1&&value+(s.trimStart||0)<=(s.mediaType==='video'?s.sourceDuration||Infinity:Infinity))editScene(s.id,{duration:value});}}/></label><label>Source volume <input type="number" className="w-20 bg-transparent border rounded p-1" min="0" max="1" step="0.1" disabled={!!draft} value={s.sourceVolume??1} onChange={e=>{const v=Number(e.target.value);if(v>=0&&v<=1)editScene(s.id,{sourceVolume:v});}}/></label></div>
        <input className="w-full bg-transparent border rounded p-2" aria-label={`Clip ${i+1} caption`} disabled={!!draft} placeholder="Caption overlay" value={s.caption} onChange={e=>onUpdate({...project,scenes:project.scenes.map(scene=>scene.id===s.id?{...scene,caption:e.target.value}:scene)})}/>
      </div>)}</div>
      <button className={button} disabled={busy || !!draft || !project.scenes.length} onClick={() => render()}>Export MP4 (FFmpeg)</button>
      {renderedUrl && <div className="space-y-3"><p>Rendered video (last completed render)</p><video src={renderedUrl} controls className="w-full max-h-96"/><div className="flex gap-4 flex-wrap"><a href={renderedUrl} download className="text-rose-500">Download MP4</a><a href="https://www.youtube.com/upload" target="_blank" rel="noopener noreferrer" className="text-rose-500">Post to YouTube</a><a href="https://vimeo.com/upload" target="_blank" rel="noopener noreferrer" className="text-rose-500">Post to Vimeo</a></div><p className="text-xs text-zinc-500">Download the MP4 first, then choose it on the platform’s upload page. For long YouTube uploads, verify your account. Platform duration and account limits still apply.</p></div>}
      <p className="text-xs text-zinc-500">Long videos render to disk and can be downloaded or shared manually. Automatic posting requires separate platform authorization. FFmpeg must be installed.</p>
      <ExportLibrary refresh={refresh}/>
    </section>
  </div>;
}
